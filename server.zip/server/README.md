# GEMIE - Serveur

## Prérequis pour le développement

### IntelliJ IDEA

Pour pouvoir compiler le serveur, il est conseiller d'installer IntelliJ IDEA. Il est possible de l'installer en suivant
les instructions sur le site officiel: https://www.jetbrains.com/idea/download/

IntelliJ IDEA a de nombreux automatismes qui permettent de simplifier le développement. Il est directement installé avec
maven et git. Il est possible de lancer le serveur en local directement depuis IntelliJ IDEA.

Notez qu'en étant étudiant, il est possible d'obtenir une licence gratuite pour IntelliJ
IDEA. [Lien vers le site officiel](https://www.jetbrains.com/community/education/#students)

Il est également possible d'utiliser un autre IDE, mais il faudra alors configurer le projet pour qu'il puisse compiler.

#### Clone du projet en local

Pour cloner le projet en local depuis IntelliJ IDEA, il faut suivre les instructions suivantes:

1. Ouvrir IntelliJ IDEA
2. Cliquer sur "Get from Version Control"
3. Choisir "Repository URL" => "Git"
4. Coller l'URL du projet : https://gitlab.emf-infopro.ch/EMF-Informatique/Production/interne/gemie/server.git
5. Cliquer sur "Clone"
6. Une fois le projet cloné, il est possible de lancer le serveur en local en cliquant sur le bouton vert "Run" en haut
   à droite, il sera accessible à l'adresse *http://localhost:8080*

#### Java 17

Le serveur GEMIE est développé en Java 17 avec le framework Spring Boot. Il est donc nécessaire d'avoir Java 17 installé
sur la machine.

Depuis IntelliJ IDEA, il est possible de télécharger Java 17 directement depuis les paramètres du projet (File > Project
Structure > Project SDK).

Lien pour télécharger Java 17 (pour un autre IDE): https://www.oracle.com/java/technologies/downloads/#java17

#### Maven

IntelliJ IDEA est livré avec Maven. Il est donc inutile de l'installer.

Pour les autres IDE, il est nécessaire d'installer Maven :

1. Lien pour télécharger Maven: https://maven.apache.org/download.cgi
2. Décompressez l'archive téléchargée dans le répertoire de votre choix.
3. Ajoutez le répertoire bin de Maven à votre variable d'environnement PATH. Cela vous permettra d'exécuter la commande
   Maven depuis n'importe quel répertoire.
4. Ouvrez un terminal et exécutez la commande suivante pour vérifier que Maven est correctement installé :

```
mvn -v
```

#### Docker

Le serveur GEMIE utilise Docker pour gérer ses conteneurs. Il est donc nécessaire d'avoir Docker installé sur la
machine.
Lien pour télécharger Docker: https://www.docker.com/products/docker-desktop

#### WampServer

Il est également nécessaire d'avoir une base de données MySQL installée sur la machine. Lien pour télécharger
WAMP: https://www.wampserver.com/

### Configuration

Le serveur GEMIE est configuré via un fichier `application.properties` situé dans le dossier `src/main/resources`. Ce
fichier contient les informations de connexion à la base de données, les informations de connexion au serveur OpenID
d'Azure ainsi que les variables d'environnement.

## Lancement

Pour lancer le serveur GEMIE dans IntelliJ IDEA, il suffit de lancer le fichier `GemieApplication.java` situé dans le
dossier `src/main/java/ch/emfinfopro/gemie/` en cliquant sur le
bouton vert en haut à droite ou "Maj + F10" pour le lancer.

Pour lancer le serveur GEMIE depuis un terminal, il faut se placer dans le dossier du projet et exécuter la commande
suivante:

```
mvn spring-boot:run
```

### Désactiver la sécurité OpenID

Pour désactiver la sécurité OpenID, il mettre en commentaire le code se trouvant dans le
fichier `ApplicationConfigation.java`
situé dans le dossier `src/main/java/ch/emfinfopro/gemie/security/` dans la méthode `filterChain`.

le code suivant:

```java

http
        .cors()
        .and()
        .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
        .and()
        .authorizeHttpRequests(configurer->
        configurer
        .requestMatchers("/swagger-ui/**","/api-docs/**","/index.html","/","/model/img/*").permitAll()
        .anyRequest()
        .authenticated()
        )
        .oauth2ResourceServer(OAuth2ResourceServerConfigurer::jwt)
        .oauth2Login(oauthLogin->oauthLogin.userInfoEndpoint()
        .oidcUserService(microsoftUserService)
        .and()
        .successHandler(myAuthenticationSuccessHandler(userService,sectionService)));

```

## Structure du projet

Le projet est structuré de la manière suivante:

```
src 
├── main
│   ├── java
│   │   └── ch
│   │       └── emfinfopro
│   │           └── gemie
│   │               ├── dto
│   │               │   ├── get
│   │               │   └── post
│   │               ├── entity
│   │               ├── exception
│   │               ├── repository
│   │               ├── security
│   │               ├── service
│   │               │   └── impl
│   │               ├── utils
│   │               ├── webController
│   │               └── GemieApplication.java
│   └── resources
└── test
```

### dto

Le dossier `dto` contient les classes qui sont utilisées pour les requêtes et les réponses. Les classes du dossier `get`
sont utilisées pour les requêtes GET et les classes du dossier `post` sont utilisées pour les requêtes POST.

Un dto permet de définir les champs qui seront envoyés dans la requête et les champs qui seront envoyés dans la réponse.
Ce qui permet d'avoir une réponse plus légère et plus rapide.

### entity

Le dossier `entity` contient les classes qui sont utilisées pour représenter les données dans la base de données. Les
classes de ce dossier sont des entités JPA.

### exception

Le dossier `exception` contient les classes qui sont utilisées pour gérer les exceptions. Les classes de ce dossier sont
utilisées pour gérer les exceptions qui sont levées par les services. Les exceptions sont ensuite gérées par la classe
`ApplicationExceptionHandler.java`.

### repository

Le dossier `repository` contient les classes qui sont utilisées pour gérer les requêtes SQL. Les classes de ce dossier
sont des repositories JPA. Les repositories sont utilisés par les services pour récupérer les données dans la base de
données.

Vous remarquerez que les repositories ne contiennent pas de requêtes SQL. Les requêtes SQL sont définies dans
l'interface `CrudRepository`.

### security

Le dossier `security` contient les classes qui sont utilisées pour gérer la sécurité du serveur. Les classes de ce
dossier sont utilisées pour gérer l'authentification et l'autorisation des utilisateurs.

### service

Le dossier `service` contient les classes qui sont utilisées pour gérer les règles métiers. Les services sont utilisés
par les webControllers pour gérer les requêtes et les réponses. Les services sont implémentés dans le dossier `impl`.

### utils

Le dossier `utils` contient les classes qui sont utilisées pour gérer les fonctions utilitaires.

### webController

Le dossier `webController` contient les classes qui sont utilisées pour gérer les requêtes et les réponses.

### GemieApplication.java

Le fichier `GemieApplication.java` est le point d'entrée du serveur. Il contient la méthode `main` qui permet de lancer
le serveur.

### resources

Le dossier `resources` contient les fichiers de configuration du serveur. Le fichier `application.properties` contient
les informations de connexion à la base de données, les informations de connexion au serveur OpenID d'Azure ainsi que
les variables d'environnement.

### test

Le dossier `test` contient les tests unitaires du serveur. Les tests unitaires sont utilisés pour tester les services et
les fonctions utilitaires.
