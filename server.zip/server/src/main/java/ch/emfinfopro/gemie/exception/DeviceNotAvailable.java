package ch.emfinfopro.gemie.exception;

public class DeviceNotAvailable extends RuntimeException {
    public DeviceNotAvailable(String inventoryNumber, String date) {
        super("L'appareil '" + inventoryNumber + "' n'est pas disponible à la date demandée. Prochainement disponible le : " + date);
    }
}
