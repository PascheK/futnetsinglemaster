package ch.emfinfopro.gemie.exception;

public class TypeNotFoundException extends RuntimeException {
    public TypeNotFoundException(int id) {
        super("Le type '" + id + "' n'existe pas dans la base de données.");
    }
}
