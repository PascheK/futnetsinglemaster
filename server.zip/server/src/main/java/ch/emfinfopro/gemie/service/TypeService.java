package ch.emfinfopro.gemie.service;

import ch.emfinfopro.gemie.dto.get.ListType;
import ch.emfinfopro.gemie.dto.post.PostType;
import ch.emfinfopro.gemie.entity.Type;

import java.util.List;

public interface TypeService {

    // =====================
    //         GET
    // =====================

    Type getType(Integer id);

    List<ListType> getTreeListTypes();

    // =====================
    //         SAVE 
    // =====================   

    Type saveType(PostType type);

    Type updateType(Integer id, PostType type);

    // =====================
    //         DELETE 
    // =====================   

    void deleteType(Integer id);

}

