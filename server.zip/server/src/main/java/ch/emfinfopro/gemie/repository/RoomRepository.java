package ch.emfinfopro.gemie.repository;

import ch.emfinfopro.gemie.entity.Room;
import ch.emfinfopro.gemie.entity.Section;
import org.springframework.data.repository.CrudRepository;

import java.util.List;


public interface RoomRepository extends CrudRepository<Room, Integer> {

    List<Room> findAllBySection(Section section);

}

