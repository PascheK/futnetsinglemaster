package ch.emfinfopro.gemie.service;

import ch.emfinfopro.gemie.entity.BookingHistory;

import java.util.Date;

public interface BookingHistoryService {

    // =====================
    //         GET
    // =====================
    String getDeviceAvailability(Integer deviceId, Date startDate, Date endDate);

    // =====================
    //         SAVE
    // =====================

    BookingHistory save(BookingHistory bookingHistory);

    // =====================
    //        DELETE
    // =====================
}
