package ch.emfinfopro.gemie.repository;

import ch.emfinfopro.gemie.entity.Device;
import ch.emfinfopro.gemie.entity.Feature;
import org.springframework.data.repository.CrudRepository;

import java.util.List;


public interface FeatureRepository extends CrudRepository<Feature, Integer> {
    List<Feature> findByDevice(Device device);
    void deleteByDevice(Device device);
}
