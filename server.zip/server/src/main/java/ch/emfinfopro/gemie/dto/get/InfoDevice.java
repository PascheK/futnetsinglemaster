package ch.emfinfopro.gemie.dto.get;

import ch.emfinfopro.gemie.entity.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class InfoDevice {
    private Integer id;
    private String inventoryNumber;
    private String name;
    private String serialNumber;
    private Date buyDate;
    private BigDecimal buyPrice;
    private Date renewalDate;
    private String image;
    private Model model;
    private Brand brand;
    private String storage;
    private Type type;
    private Device.State state;
    private Room room;
    private Integer managerId;
    private String managerName;
    private String managerEmail;
    private List<Feature> features;
    private List<DateOfBooking> unavailableDates;
}
