package ch.emfinfopro.gemie.service;

import ch.emfinfopro.gemie.dto.post.PostUser;
import ch.emfinfopro.gemie.entity.User;

import java.util.List;
import java.util.Map;

public interface UserService {

    // =====================
    //         GET
    // =====================

    List<User> getUsers();

    User getUser(Integer id);

    Map<String, Object> getUserClaims();

    List<User.Role> getRoles();

    User getUserByMicrosoftId(String id);

    User getConnectedUser();

    // =====================
    //         SAVE 
    // =====================

    User registerUser(User user);

    User updateUser(Integer id, PostUser user);

    // =====================
    //         DELETE 
    // =====================   

    void deleteUser(Integer id);



}
