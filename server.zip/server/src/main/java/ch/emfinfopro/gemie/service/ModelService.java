package ch.emfinfopro.gemie.service;

import ch.emfinfopro.gemie.dto.post.PostModel;
import ch.emfinfopro.gemie.entity.Model;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface ModelService {

    // =====================
    //         GET
    // =====================

    List<Model> getModels();

    Model getModel(Integer id);

    byte[] getImg(Integer id);

    // =====================
    //         SAVE
    // =====================

    Model saveModel(PostModel model);

    Model updateModel(Integer id, PostModel model);

    Model updateImage(Integer id, MultipartFile image);

    // =====================
    //        DELETE
    // =====================

    void deleteModel(Integer id);


}
