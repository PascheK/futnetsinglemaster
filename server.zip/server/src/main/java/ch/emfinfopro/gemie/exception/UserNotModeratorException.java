package ch.emfinfopro.gemie.exception;

public class UserNotModeratorException extends RuntimeException {
    public UserNotModeratorException() {
        super("L'utilisateur n'est pas modérateur.");
    }
}
