package ch.emfinfopro.gemie.exception;

public class BookingNotInProgressException extends RuntimeException {
    public BookingNotInProgressException() {
        super("L'emprunt n'est pas en cours.");
    }
}
