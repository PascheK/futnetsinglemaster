package ch.emfinfopro.gemie.exception;

public class SchoolNotFoundException extends RuntimeException {
    public SchoolNotFoundException(int id) {
        super("L'école '" + id + "' n'existe pas dans la base de données.");
    }
}
