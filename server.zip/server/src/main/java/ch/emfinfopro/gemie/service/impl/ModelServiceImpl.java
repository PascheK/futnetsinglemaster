package ch.emfinfopro.gemie.service.impl;

import ch.emfinfopro.gemie.dto.post.PostModel;
import ch.emfinfopro.gemie.entity.Model;
import ch.emfinfopro.gemie.entity.User;
import ch.emfinfopro.gemie.exception.ForbiddenException;
import ch.emfinfopro.gemie.exception.ImageException;
import ch.emfinfopro.gemie.exception.ModelHasNoImageException;
import ch.emfinfopro.gemie.exception.ModelNotFoundException;
import ch.emfinfopro.gemie.repository.ModelRepository;
import ch.emfinfopro.gemie.service.BrandService;
import ch.emfinfopro.gemie.service.ModelService;
import ch.emfinfopro.gemie.service.UserService;
import ch.emfinfopro.gemie.utils.ImageUtility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
public class ModelServiceImpl implements ModelService {

    @Autowired
    ModelRepository modelRepository;

    @Autowired
    BrandService brandService;

    @Autowired
    UserService userService;

    // =====================
    //         GET
    // =====================

    @Override
    /**
     * Get all models
     * return list of models
     */
    public List<Model> getModels() {
        return (List<Model>) modelRepository.findAll();
    }

    @Override
    /**
     * Get a model by id
     * @param id
     * @return Model
     */
    public Model getModel(Integer id) {
        Optional<Model> model = modelRepository.findById(id);
        if (model.isPresent()) {
            return model.get();
        } else {
            throw new ModelNotFoundException(id);
        }
    }


    @Override
    /**
     * Get the model image by id
     *
     * @param name
     * @return Model image
     */
    public byte[] getImg(Integer id) {
        Optional<Model> model = modelRepository.findById(id);
        if (model.isPresent()) {
            if (model.get().getImg() != null) {
                    return ImageUtility.decompressImage(model.get().getImg());
            } else {
                throw new ModelHasNoImageException(id);
            }
        } else {
            throw new ModelNotFoundException(id);
        }

    }

    // =====================
    //         SAVE
    // =====================


    @Override
    /**
     * Save a new model
     * @param model
     * @return the saved model
     */
    public Model saveModel(PostModel model) {
        User connectedUser = userService.getConnectedUser();

        if (connectedUser.getRole() == User.Role.USER) throw new ForbiddenException();

        Logger logger = LoggerFactory.getLogger(ModelServiceImpl.class);
        logger.info("INSERT - Model : '{}' by {} ({})", model.getLabel(), connectedUser.getName(), connectedUser.getEmail());

        return modelRepository.save(mapToEntity(model));
    }

    @Override
    public Model updateModel(Integer id, PostModel model) {
        User connectedUser = userService.getConnectedUser();

        if (connectedUser.getRole() == User.Role.USER) throw new ForbiddenException();

        Logger logger = LoggerFactory.getLogger(ModelServiceImpl.class);
        logger.info("UPDATE - Model : '{}' by {} ({})", id, connectedUser.getName(), connectedUser.getEmail());

        Model modelToUpdate = getModel(id);
        modelToUpdate.setLabel(model.getLabel());
        modelToUpdate.setBrand(brandService.getBrand(model.getBrandId()));
        return modelRepository.save(modelToUpdate);
    }

    @Override
    public Model updateImage(Integer id, MultipartFile image) {
        User connectedUser = userService.getConnectedUser();

        if (connectedUser.getRole() == User.Role.USER) throw new ForbiddenException();

        Logger logger = LoggerFactory.getLogger(ModelServiceImpl.class);
        logger.info("UPDATE - Model image : '{}' by {} ({})", id, connectedUser.getName(), connectedUser.getEmail());

        Model modelToUpdate = getModel(id);
        try {
            modelToUpdate.setImg(image != null ? ImageUtility.compressImage(image.getBytes()) : null);
        } catch (IOException e) {
            throw new ImageException();
        }
        return modelRepository.save(modelToUpdate);
    }

    // =====================
    //         DELETE
    // =====================

    @Override
    /**
     * Delete a model
     * @param id
     */
    public void deleteModel(Integer id) {
        modelRepository.deleteById(id);
    }

    // =====================
    //         UTILS
    // =====================

    /**
     * Map a PostModel to a Model
     * @param model
     * @return Model
     */
    private Model mapToEntity(PostModel model) {
        Model modelToSave = new Model();
        modelToSave.setLabel(model.getLabel());
        modelToSave.setBrand(brandService.getBrand(model.getBrandId()));
        return modelToSave;
    }

}
