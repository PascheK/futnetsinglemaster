package ch.emfinfopro.gemie.service.impl;

import ch.emfinfopro.gemie.dto.post.PostBrand;
import ch.emfinfopro.gemie.entity.Brand;
import ch.emfinfopro.gemie.entity.User;
import ch.emfinfopro.gemie.exception.BrandNotFoundException;
import ch.emfinfopro.gemie.exception.ForbiddenException;
import ch.emfinfopro.gemie.repository.BrandRepository;
import ch.emfinfopro.gemie.service.BrandService;
import ch.emfinfopro.gemie.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BrandServiceImpl implements BrandService {

    @Autowired
    BrandRepository brandRepository;

    @Autowired
    UserService userService;

    // =====================
    //         GET
    // =====================

    @Override
    /**
     * Get all brands
     * return list of brands
     */
    public List<Brand> getBrands() {
        return (List<Brand>) brandRepository.findAll();
    }

    @Override
    /**
     * Get a brand by id
     * @param id
     * @return Brand
     */
    public Brand getBrand(Integer id) {
        Optional<Brand> brand = brandRepository.findById(id);
        if (brand.isPresent()) {
            return brand.get();
        } else {
            throw new BrandNotFoundException(id);
        }
    }


    // =====================
    //         SAVE
    // =====================


    @Override
    /**
     * Save a new brand
     * @param brand
     * @return the saved brand
     */
    public Brand saveBrand(PostBrand brand) {
        User connectedUser = userService.getConnectedUser();

        if (connectedUser.getRole() == User.Role.USER) throw new ForbiddenException();

        Logger logger = LoggerFactory.getLogger(BrandServiceImpl.class);
        logger.info("INSERT - Brand : '{}' by {} ({})", brand.getLabel(), connectedUser.getName(), connectedUser.getEmail());

        return brandRepository.save(mapToEntity(brand));
    }

    @Override
    public Brand updateBrand(Integer id, PostBrand brand) {
        User connectedUser = userService.getConnectedUser();

        if (connectedUser.getRole() == User.Role.USER) throw new ForbiddenException();

        Logger logger = LoggerFactory.getLogger(BrandServiceImpl.class);
        logger.info("UPDATE - Brand : '{}' by {} ({})", brand.getLabel(), connectedUser.getName(), connectedUser.getEmail());

        Brand brandToUpdate = getBrand(id);
        brandToUpdate.setLabel(brand.getLabel());
        return brandRepository.save(brandToUpdate);
    }

    // =====================
    //         DELETE
    // =====================

    @Override
    /**
     * Delete a brand
     * @param id
     */
    public void deleteBrand(Integer id) {
        brandRepository.deleteById(id);
    }

    // =====================
    //         UTILS
    // =====================

    /**
     * Map a PostBrand to a Brand
     * @param brand
     * @return Brand
     */
    private Brand mapToEntity(PostBrand brand) {
        Brand brandToSave = new Brand();
        brandToSave.setLabel(brand.getLabel());
        return brandToSave;
    }

}
