package ch.emfinfopro.gemie.repository;

import ch.emfinfopro.gemie.entity.Booking;
import ch.emfinfopro.gemie.entity.User;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface BookingRepository extends CrudRepository<Booking, Integer> {

    List<Booking> findAllByUser(User user);

}
