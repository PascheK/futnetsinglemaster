package ch.emfinfopro.gemie.service.impl;

import ch.emfinfopro.gemie.dto.get.InfoBookingDevice;
import ch.emfinfopro.gemie.dto.get.ListBooking;
import ch.emfinfopro.gemie.dto.post.PostBooking;
import ch.emfinfopro.gemie.dto.post.PostReturnDevices;
import ch.emfinfopro.gemie.dto.post.PostValidation;
import ch.emfinfopro.gemie.entity.Booking;
import ch.emfinfopro.gemie.entity.BookingHistory;
import ch.emfinfopro.gemie.entity.Device;
import ch.emfinfopro.gemie.entity.User;
import ch.emfinfopro.gemie.exception.*;
import ch.emfinfopro.gemie.repository.BookingRepository;
import ch.emfinfopro.gemie.service.BookingHistoryService;
import ch.emfinfopro.gemie.service.BookingService;
import ch.emfinfopro.gemie.service.DeviceService;
import ch.emfinfopro.gemie.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class BookingServiceImpl implements BookingService {

    @Autowired
    BookingRepository bookingRepository;

    @Autowired
    BookingHistoryService bookingHistoryService;

    @Autowired
    UserService userService;

    @Autowired
    DeviceService deviceService;


    // =====================
    //         GET
    // =====================

    @Override
    public List<ListBooking> getBookings() {
        User connectedUser = userService.getConnectedUser();

        if (connectedUser.getRole() == User.Role.USER) throw new ForbiddenException();

        List<Booking> bookings = (List<Booking>) bookingRepository.findAll();
        return bookings.stream().map(this::mapToDTOList).toList();

    }

    @Override
    public List<ListBooking> getBookingsByUser() {
        List<Booking> bookings;
        User connectedUser = userService.getConnectedUser();
        bookings = bookingRepository.findAllByUser(connectedUser);
        bookings.stream().filter(booking -> booking.getStartDate().before(Timestamp.from(Instant.now())) && booking.getBookinghistories().stream().anyMatch(bookingHistory -> bookingHistory.getReturnDate() == null) && booking.getState() == Booking.State.FUTUR).forEach(booking -> booking.setState(Booking.State.IN_PROGRESS));
        return bookings.stream().map(this::mapToDTOList).toList();
    }

    @Override
    public Booking getBooking(Integer id) {
        User connectedUser = userService.getConnectedUser();
        Optional<Booking> booking = bookingRepository.findById(id);

        if (booking.isEmpty()) throw new DeviceNotFoundException(id.toString());
        if (connectedUser.getRole() == User.Role.USER && connectedUser.getId() != booking.get().getUser().getId())
            throw new ForbiddenException();

        return booking.get();
    }

    @Override
    public List<Booking.State> getStates() {
        return Arrays.asList(Booking.State.values());
    }


    // =====================
    //         SAVE
    // =====================

    @Override
    public Booking saveBooking(PostBooking postBooking) {

        for (Integer deviceId : postBooking.getDevicesIds()) {
            String availability = bookingHistoryService.getDeviceAvailability(deviceId, postBooking.getStartDate(), postBooking.getEstimateEndDate());
            if (availability != null) {
                Device deviceNotAvailble = deviceService.getDevice(deviceId);
                throw new DeviceNotAvailable(deviceNotAvailble.getInventoryNumber(), availability);
            }
        }

        User connectedUser = userService.getConnectedUser();

        Booking saveBooking = new Booking();
        saveBooking.setUser(connectedUser);
        saveBooking.setReason(postBooking.getReason());
        saveBooking.setEstimateEndDate(postBooking.getEstimateEndDate());
        saveBooking.setStartDate(postBooking.getStartDate());

        if (postBooking.getDevicesIds().stream().anyMatch(deviceId -> deviceService.getDevice(deviceId).getModeratorControl())) {
            saveBooking.setState(Booking.State.IN_VALIDATION);
            //TODO: mail to moderator
        } else if (postBooking.getStartDate().before(Timestamp.from(Instant.now()))) {
            saveBooking.setState(Booking.State.IN_PROGRESS);
        } else {
            saveBooking.setState(Booking.State.FUTUR);
        }

        Booking booking = bookingRepository.save(saveBooking);

        for (Integer deviceId : postBooking.getDevicesIds()) {
            Device device = deviceService.getDevice(deviceId);
            BookingHistory bookingHistory = new BookingHistory();
            bookingHistory.setDevice(device);
            bookingHistory.setBooking(booking);
            bookingHistoryService.save(bookingHistory);
        }

        Logger logger = LoggerFactory.getLogger(BookingServiceImpl.class);
        logger.info("INSERT - Booking : {} by {} ({})", booking.getId(), connectedUser.getName(), connectedUser.getEmail());

        return booking;
    }

    /**
     * Validate a booking
     *
     * @param validation
     * @return
     */
    @Override
    public Booking validateBooking(PostValidation validation) {
        User connectedUser = userService.getConnectedUser();
        User.Role roleConnectedUser = connectedUser.getRole();
        Booking booking = getBooking(validation.getBookingId());
        if (roleConnectedUser != User.Role.USER) {
            if (validation.isValidation()) {
                if (booking.getBookinghistories().stream().allMatch(bookingHistory -> bookingHistory.getReturnDate() != null)) {
                    booking.setState(Booking.State.COMPLETE);
                } else {
                    if (booking.getStartDate().before(Timestamp.from(Instant.now()))) {
                        booking.setState(Booking.State.IN_PROGRESS);
                    } else {
                        booking.setState(Booking.State.FUTUR);
                    }
                }
            } else {
                if (booking.getBookinghistories().stream().allMatch(bookingHistory -> bookingHistory.getReturnDate() != null)) {
                    booking.getBookinghistories().forEach(bookingHistory -> {
                        if (validation.getDevicesIds().contains(bookingHistory.getDevice().getId())) {
                            bookingHistory.setReturnDate(null);
                        }
                    });
                    booking.setState(Booking.State.IN_PROGRESS);
                } else {
                    booking.setState(Booking.State.DENIED);
                }
            }
        } else {
            throw new UserNotModeratorException();
        }

        Logger logger = LoggerFactory.getLogger(BookingServiceImpl.class);
        logger.info("VALIDATION - Booking : {} by {} ({})", booking.getId(), connectedUser.getName(), connectedUser.getEmail());

        return bookingRepository.save(booking);
    }

    @Override
    public ListBooking returnDevices(PostReturnDevices returnDevices) {
        Booking bookingToUpdate = getBooking(returnDevices.getBookingId());
        User connectedUser = userService.getConnectedUser();
        User.Role roleConnectedUser = connectedUser.getRole();
        String idConnectedUser = connectedUser.getMicrosoftId();

        if (bookingToUpdate.getStartDate().before(Timestamp.from(Instant.now())) && bookingToUpdate.getBookinghistories().stream().anyMatch(bookingHistory -> bookingHistory.getReturnDate() == null) && bookingToUpdate.getState() == Booking.State.FUTUR) {
            bookingToUpdate.setState(Booking.State.IN_PROGRESS);
        }

        if (bookingToUpdate.getUser().getMicrosoftId().equals(idConnectedUser) || roleConnectedUser != User.Role.USER) {
            if (connectedUser.getRole() == User.Role.MODO && bookingToUpdate.getUser().getRole() == User.Role.ADMIN)
                throw new ForbiddenException();
            switch (bookingToUpdate.getState()) {
                case FUTUR:
                    bookingToUpdate.getBookinghistories().forEach(bookingHistory -> {

                        if (returnDevices.getDevicesIds().contains(bookingHistory.getDevice().getId())) {
                            bookingHistory.setReturnDate(Timestamp.from(Instant.now()));
                        }
                    });
                    if (bookingToUpdate.getBookinghistories().stream().anyMatch(bookingHistory -> bookingHistory.getReturnDate() == null)) {
                        bookingToUpdate.setState(Booking.State.FUTUR);
                    } else {
                        bookingToUpdate.setState(Booking.State.CANCELED);
                    }
                    break;
                case IN_PROGRESS, IN_VALIDATION:
                    bookingToUpdate.getBookinghistories().forEach(bookingHistory -> {
                        if (returnDevices.getDevicesIds().contains(bookingHistory.getDevice().getId())) {
                            if (bookingHistory.getReturnDate() == null) {
                                bookingHistory.setReturnDate(Timestamp.from(Instant.now()));
                                if (bookingHistory.getDevice().getModeratorControl()) {
                                    bookingToUpdate.setState(Booking.State.IN_VALIDATION);
                                } else if (bookingToUpdate.getState() != Booking.State.IN_VALIDATION) {
                                    if (bookingToUpdate.getBookinghistories().stream().allMatch(bookingHistoryMatch -> bookingHistoryMatch.getReturnDate() != null)) {
                                        bookingToUpdate.setState(Booking.State.COMPLETE);
                                    }
                                }
                                bookingHistoryService.save(bookingHistory);
                            } else {
                                throw new DeviceAlreadyReturnedException(bookingHistory.getDevice().getInventoryNumber(), bookingToUpdate.getId());
                            }
                        }
                    });
                    break;
                case COMPLETE, DENIED, CANCELED:
                    throw new BookingNotInProgressException();
            }
        } else {
            throw new UserNotModeratorException();
        }

        //TODO: mail

        return mapToDTOList(bookingRepository.save(bookingToUpdate));
    }

    @Override
    public Booking updateBooking(Integer id, PostBooking booking) {
        User connectedUser = userService.getConnectedUser();
        Booking bookingToUpdate = getBooking(id);

        if (
                (connectedUser.getRole() == User.Role.USER && bookingToUpdate.getUser().getId() != connectedUser.getId())
                || (connectedUser.getRole() == User.Role.MODO && bookingToUpdate.getUser().getRole() == User.Role.ADMIN)
        )
            throw new ForbiddenException();

        bookingToUpdate.setReason(booking.getReason());
        bookingToUpdate.setEstimateEndDate(booking.getEstimateEndDate());
        bookingToUpdate.setStartDate(booking.getStartDate());

        if (booking.getStartDate().before(Timestamp.from(Instant.now()))) {
            bookingToUpdate.setState(Booking.State.IN_PROGRESS);
        } else {
            bookingToUpdate.setState(Booking.State.FUTUR);
        }

        Logger logger = LoggerFactory.getLogger(BookingServiceImpl.class);
        logger.info("UPDATE - Booking : {} by {} ({})", bookingToUpdate.getId(), connectedUser.getName(), connectedUser.getEmail());
        
        return bookingRepository.save(bookingToUpdate);
    }

    // =====================
    //         DELETE
    // =====================

    @Override
    public void deleteBooking(Integer id) {
        bookingRepository.deleteById(id);
    }

    // =====================
    //         UTILS
    // =====================

    private ListBooking mapToDTOList(Booking booking) {
        ListBooking listBooking = new ListBooking();
        listBooking.setId(booking.getId());
        listBooking.setUserEmail(booking.getUser().getEmail());
        listBooking.setUserName(booking.getUser().getName());
        listBooking.setReason(booking.getReason());
        listBooking.setState(booking.getState());
        listBooking.setStartDate(booking.getStartDate());
        listBooking.setEstimateEndDate(booking.getEstimateEndDate());
        listBooking.setDevices(booking.getBookinghistories().stream().map(this::mapToDTOInfoBooking).toList());
        return listBooking;
    }

    public InfoBookingDevice mapToDTOInfoBooking(BookingHistory bookingHistory) {
        InfoBookingDevice infoBookingDevice = new InfoBookingDevice();
        Device device = bookingHistory.getDevice();
        infoBookingDevice.setId(device.getId());
        infoBookingDevice.setInventoryNumber(device.getInventoryNumber());
        infoBookingDevice.setName(device.getName());
        infoBookingDevice.setReturned(bookingHistory.getReturnDate() != null);
        infoBookingDevice.setReturnDate(bookingHistory.getReturnDate());
        return infoBookingDevice;
    }
}
