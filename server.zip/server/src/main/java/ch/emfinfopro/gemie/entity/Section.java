package ch.emfinfopro.gemie.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@RequiredArgsConstructor
@Entity
@Table(name = "section")
public class Section {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Size(max = 45)
    @NonNull
    @NotNull
    @Column(name = "name", nullable = false, length = 45)
    private String label;

    @Size(max = 10)
    @NonNull
    @NotNull
    @Column(name = "initials", nullable = false, length = 10)
    private String initials;

    @NonNull
    @NotNull
    @ManyToOne(optional = false)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY,mappedBy = "section")
    private List<User> users;

    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY,mappedBy = "section")
    private List<Type> types;

    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY,mappedBy = "section")
    private List<Room> rooms;

}