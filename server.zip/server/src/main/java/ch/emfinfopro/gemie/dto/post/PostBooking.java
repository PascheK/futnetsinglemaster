package ch.emfinfopro.gemie.dto.post;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class PostBooking {
    private List<Integer> devicesIds;
    private String reason;
    private Date startDate;
    private Date estimateEndDate;
}
