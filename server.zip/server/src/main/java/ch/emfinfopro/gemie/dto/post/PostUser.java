package ch.emfinfopro.gemie.dto.post;

import ch.emfinfopro.gemie.entity.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.lang.Nullable;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class PostUser {
    @Nullable
    private String phone;
    private boolean active;
    private User.Role role;
    @Nullable
    private Integer sectionId;
}
