package ch.emfinfopro.gemie.service.impl;

import ch.emfinfopro.gemie.dto.get.ListType;
import ch.emfinfopro.gemie.dto.post.PostType;
import ch.emfinfopro.gemie.entity.Type;
import ch.emfinfopro.gemie.entity.User;
import ch.emfinfopro.gemie.exception.ForbiddenException;
import ch.emfinfopro.gemie.exception.TypeNotFoundException;
import ch.emfinfopro.gemie.repository.TypeRepository;
import ch.emfinfopro.gemie.service.TypeService;
import ch.emfinfopro.gemie.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TypeServiceImpl implements TypeService {

    @Autowired
    TypeRepository typeRepository;

    @Autowired
    UserService userService;

    // =====================
    //         GET
    // =====================

    public List<ListType> getTreeListTypes() {
        List<Type> types;
        User connectedUser = userService.getConnectedUser();
        User.Role userRole = connectedUser.getRole();
        if (userRole == User.Role.ADMIN) {
            types = typeRepository.findAllByParentTypeIsNull();
        } else {
            types = typeRepository.findAllByParentTypeIsNullAndSection(connectedUser.getSection());
        }
        return types.stream().map(this::mapToDTOList).toList();
    }

    @Override
    public Type getType(Integer id) {
        Optional<Type> type = typeRepository.findById(id);
        if (type.isPresent()) {
            return type.get();
        } else {
            throw new TypeNotFoundException(id);
        }
    }

    // =====================
    //         SAVE
    // =====================

    @Override
    public Type saveType(PostType type) {
        User connectedUser = userService.getConnectedUser();

        if (connectedUser.getRole() == User.Role.USER) throw new ForbiddenException();

        Logger logger = LoggerFactory.getLogger(TypeServiceImpl.class);
        logger.info("INSERT - Type : '{}' by {} ({})", type.getLabel(), connectedUser.getName(), connectedUser.getEmail());

        return typeRepository.save(mapToEntity(type));
    }

    @Override
    public Type updateType(Integer id, PostType type) {
        User connectedUser = userService.getConnectedUser();

        if (connectedUser.getRole() == User.Role.USER) throw new ForbiddenException();

        Logger logger = LoggerFactory.getLogger(TypeServiceImpl.class);
        logger.info("INSERT - Type : '{}' by {} ({})", id, connectedUser.getName(), connectedUser.getEmail());

        Type typeToUpdate = getType(id);
        typeToUpdate.setLabel(type.getLabel());
        typeToUpdate.setParentType(getType(type.getParentTypeId()));
        return typeRepository.save(typeToUpdate);
    }

    // =====================
    //         DELETE
    // =====================

    @Override
    public void deleteType(Integer id) {
        typeRepository.deleteById(id);
    }


    // =====================
    //         UTILS
    // =====================

    private Type mapToEntity(PostType type) {
        //get connected user
        Type typeToSave = new Type();
        User connectedUser = userService.getConnectedUser();
        typeToSave.setLabel(type.getLabel());
        typeToSave.setSection(connectedUser.getSection());
        typeToSave.setParentType(type.getParentTypeId() != null ? getType(type.getParentTypeId()) : null);
        return typeToSave;
    }

    private ListType mapToDTOList(Type type) {
        ListType typeListDto = new ListType();
        typeListDto.setId(type.getId());
        typeListDto.setLabel(type.getLabel());
        typeListDto.setChildren(type.getChildren().stream().map(this::mapToDTOList).toList());
        typeListDto.setParentId(type.getParentType() != null ? type.getParentType().getId() : null);
        return typeListDto;
    }
}
