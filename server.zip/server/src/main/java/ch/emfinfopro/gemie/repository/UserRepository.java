package ch.emfinfopro.gemie.repository;

import ch.emfinfopro.gemie.entity.User;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface UserRepository extends CrudRepository<User, Integer> {

    Optional<User> findByMicrosoftId(String id);

}
