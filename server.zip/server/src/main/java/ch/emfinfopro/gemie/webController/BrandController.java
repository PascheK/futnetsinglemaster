package ch.emfinfopro.gemie.webController;

import ch.emfinfopro.gemie.dto.post.PostBrand;
import ch.emfinfopro.gemie.entity.Brand;
import ch.emfinfopro.gemie.service.BrandService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller for the brand entity
 *
 * @author Paulo Venancio Jordao
 * @version 2.0
 */
@CrossOrigin
@RestController
@RequestMapping("/brand")
@SecurityRequirement(name = "token")
public class BrandController {

    @Autowired
    BrandService brandService;

    // =====================
    //         GET
    // =====================

    @GetMapping(value = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Brand> getBrands() {
        return brandService.getBrands();
    }

    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Brand getBrand(@PathVariable Integer id) {
        return brandService.getBrand(id);
    }

    // =====================
    //         POST 
    // =====================

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Brand saveBrand(@RequestBody PostBrand brand) {
        return brandService.saveBrand(brand);
    }

    // =====================
    //         PUT 
    // =====================

    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Brand updateBrand(@PathVariable Integer id, @RequestBody PostBrand brand) {
        return brandService.updateBrand(id, brand);
    }

}
