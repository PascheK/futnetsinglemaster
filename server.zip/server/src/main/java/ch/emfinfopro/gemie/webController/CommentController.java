package ch.emfinfopro.gemie.webController;

import ch.emfinfopro.gemie.dto.post.PostComment;
import ch.emfinfopro.gemie.entity.Comment;
import ch.emfinfopro.gemie.service.CommentService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller for the comment entity
 *
 * @author Paulo Venancio Jordao
 * @version 2.0
 */
@CrossOrigin
@RestController
@RequestMapping("/comment")
@SecurityRequirement(name = "token")
public class CommentController {

    @Autowired
    CommentService commentService;

    // =====================
    //         GET
    // =====================


    @GetMapping(value = "/device/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Comment> getCommentsByDevice(@PathVariable Integer id) {
        return commentService.getCommentsByDevice(id);
    }

    // =====================
    //         POST
    // =====================

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Comment saveComment(@RequestBody PostComment comment) {
        return commentService.saveComment(comment);
    }

    // =====================
    //         PUT
    // =====================

    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Comment updateComment(@PathVariable Integer id, @RequestBody PostComment comment) {
        return commentService.updateComment(id, comment);
    }

}
