package ch.emfinfopro.gemie.exception;

public class RoomNotFoundException extends RuntimeException {
    public RoomNotFoundException(int id) {
        super("La salle '" + id + "' n'existe pas dans la base de données.");
    }
}

