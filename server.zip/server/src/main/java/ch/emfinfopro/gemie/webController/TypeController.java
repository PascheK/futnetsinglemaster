package ch.emfinfopro.gemie.webController;

import ch.emfinfopro.gemie.dto.get.ListType;
import ch.emfinfopro.gemie.dto.post.PostType;
import ch.emfinfopro.gemie.entity.Type;
import ch.emfinfopro.gemie.service.TypeService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller for the type entity
 *
 * @author Paulo Venancio Jordao
 * @version 2.0
 */
@CrossOrigin
@RestController
@RequestMapping("/type")
@SecurityRequirement(name = "token")
public class TypeController {

    @Autowired
    TypeService typeService;


    // =====================
    //         GET
    // =====================

    /**
     * Get all types
     *
     * @return List of types
     */
    @GetMapping(value = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<ListType> getTreeListTypes() {
        return typeService.getTreeListTypes();
    }

    /**
     * Get a type by id
     *
     * @param id Type id
     * @return Type
     */
    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Type getType(@PathVariable Integer id) {
        return typeService.getType(id);
    }

    // =====================
    //         POST 
    // =====================   

    /**
     * Save a type
     *
     * @param type Type
     * @return Type
     */
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Type saveType(@RequestBody PostType type) {
        return typeService.saveType(type);
    }

    // =====================
    //         PUT 
    // =====================

    /**
     * Update a type
     *
     * @param type Type
     * @return Type
     */
    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Type updateType(@PathVariable Integer id, @RequestBody PostType type) {
         return typeService.updateType(id, type);
    }

}
