package ch.emfinfopro.gemie.service.impl;

import ch.emfinfopro.gemie.dto.post.PostRoom;
import ch.emfinfopro.gemie.entity.Room;
import ch.emfinfopro.gemie.entity.User;
import ch.emfinfopro.gemie.exception.ForbiddenException;
import ch.emfinfopro.gemie.exception.RoomNotFoundException;
import ch.emfinfopro.gemie.repository.RoomRepository;
import ch.emfinfopro.gemie.service.RoomService;
import ch.emfinfopro.gemie.service.SectionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RoomServiceImpl implements RoomService {

    @Autowired
    RoomRepository roomRepository;

    @Autowired
    SectionService sectionService;

    @Autowired
    UserServiceImpl userService;

    // =====================
    //         GET
    // =====================

    @Override
    public List<Room> getRooms() {
        List<Room> rooms;
        User connectedUser = userService.getConnectedUser();
        User.Role userRole = connectedUser.getRole();
        if (userRole == User.Role.ADMIN) {
            rooms = (List<Room>) roomRepository.findAll();
        } else {
            rooms = roomRepository.findAllBySection(connectedUser.getSection());
        }

        return rooms;
    }

    @Override
    public Room getRoom(Integer id) {
        Optional<Room> room = roomRepository.findById(id);
        if (room.isPresent()) {
            return room.get();
        } else {
            throw new RoomNotFoundException(id);
        }
    }

    // =====================
    //         SAVE
    // =====================

    @Override
    public Room saveRoom(PostRoom room) {
        User connectedUser = userService.getConnectedUser();

        if (connectedUser.getRole() == User.Role.USER) throw new ForbiddenException();

        Logger logger = LoggerFactory.getLogger(RoomServiceImpl.class);
        logger.info("INSERT - Room : '{}' by {} ({})", room.getLabel(), connectedUser.getName(), connectedUser.getEmail());

        return roomRepository.save(mapToEntity(room));
    }

    @Override
    public Room updateRoom(Integer id, PostRoom room) {
        User connectedUser = userService.getConnectedUser();

        if (connectedUser.getRole() == User.Role.USER) throw new ForbiddenException();

        Logger logger = LoggerFactory.getLogger(RoomServiceImpl.class);
        logger.info("UPDATE - Room : '{}' by {} ({})", id, connectedUser.getName(), connectedUser.getEmail());


        Room roomToUpdate = getRoom(id);
        roomToUpdate.setLabel(room.getLabel());
        roomToUpdate.setSection(sectionService.getSection(room.getSectionId()));
        return roomRepository.save(roomToUpdate);
    }

    // =====================
    //         DELETE
    // =====================

    @Override
    public void deleteRoom(Integer id) {
        roomRepository.deleteById(id);
    }


    // =====================
    //         UTILS
    // =====================

    private Room mapToEntity(PostRoom room) {
        Room entity = new Room();
        entity.setLabel(room.getLabel());
        entity.setSection(sectionService.getSection(room.getSectionId()));
        return entity;
    }

}

