package ch.emfinfopro.gemie.exception;

public class UserNotFoundException extends RuntimeException {
    public UserNotFoundException(String id) {
        super("L'utilisateur '" + id + "' n'existe pas dans la base de données.");
    }
}