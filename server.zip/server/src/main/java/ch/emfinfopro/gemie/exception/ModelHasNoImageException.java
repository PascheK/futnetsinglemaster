package ch.emfinfopro.gemie.exception;

public class ModelHasNoImageException extends RuntimeException {
    public ModelHasNoImageException(int id) {
        super("Le modèle '" + id + "' n'a pas d'image dans la base de données.");
    }
}


