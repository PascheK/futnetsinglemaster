package ch.emfinfopro.gemie.repository;

import ch.emfinfopro.gemie.entity.School;
import org.springframework.data.repository.CrudRepository;

public interface SchoolRepository extends CrudRepository<School, Integer> {
}
