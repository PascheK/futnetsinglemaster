package ch.emfinfopro.gemie.exception;

public class ModelNotFoundException extends RuntimeException {
    public ModelNotFoundException(int id) {
        super("Le modèle '" + id + "' n'existe pas dans la base de données.");
    }
}


