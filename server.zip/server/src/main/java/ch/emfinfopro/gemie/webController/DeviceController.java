package ch.emfinfopro.gemie.webController;

import ch.emfinfopro.gemie.dto.get.InfoDevice;
import ch.emfinfopro.gemie.dto.get.ListDevice;
import ch.emfinfopro.gemie.dto.post.PostDevice;
import ch.emfinfopro.gemie.entity.Device;
import ch.emfinfopro.gemie.service.DeviceService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller for the device entity
 *
 * @author Paulo Venancio Jordao
 * @version 2.0
 */
@CrossOrigin
@RestController
@RequestMapping("/device")
@SecurityRequirement(name = "token")
public class DeviceController {

    @Autowired
    DeviceService deviceService;


    // =====================
    //         GET
    // =====================

    /**
     * Get all devices
     *
     * @return List of devices
     */
    @GetMapping(value = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<ListDevice> getDevices() {
        return deviceService.getDevices();
    }

    /**
     * Get all inventory number
     *
     * @return
     */
    @GetMapping(value = "/inventoryNumber", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<String> getDevicesId() {
        return deviceService.getDevicesInventoryNumber();
    }

    /**
     * Get a device by id
     *
     * @param id
     * @return
     */
    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public InfoDevice getDevice(@PathVariable Integer id) {
        return deviceService.getDeviceInfo(id);
    }

    /**
     * Get device by inventory number
     *
     * @param inventoryNumber
     * @return
     */
    @GetMapping(value = "/inventoryNumber/{inventoryNumber}", produces = MediaType.APPLICATION_JSON_VALUE)
    public InfoDevice getDeviceByInventoryNumber(@PathVariable String inventoryNumber) {
        return deviceService.getDeviceByInventoryNumber(inventoryNumber);
    }

    /**
     * Get device states
     *
     * @return
     */
    @GetMapping(value = "/states", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Device.State> getStates() {
        return deviceService.getStates();
    }

    // =====================
    //         POST 
    // =====================   

    /**
     * Save a device
     *
     * @param
     * @return
     */
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Device saveDevice(@RequestBody PostDevice device) {
        return deviceService.saveDevice(device);
    }

    // =====================
    //         PUT 
    // =====================   

    /**
     * Update a device
     *
     * @param id
     * @param
     * @return
     */
    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Device updateDevice(@PathVariable Integer id, @RequestBody PostDevice device) {
        return deviceService.updateDevice(id, device);
    }

}
