package ch.emfinfopro.gemie.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@RequiredArgsConstructor
@Entity
@Table(name = "bookinghistory")
public class BookingHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @NonNull
    @NotNull
    @ManyToOne(optional = false)
    @JoinColumn(name = "booking_id", nullable = false, referencedColumnName = "id")
    private Booking booking;

    @NonNull
    @NotNull
    @ManyToOne(optional = false)
    @JoinColumn(name = "device_id", nullable = false, referencedColumnName = "id")
    private Device device;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "return_date")
    private Date returnDate;

}