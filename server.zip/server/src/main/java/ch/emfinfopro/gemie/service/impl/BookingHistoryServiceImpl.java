package ch.emfinfopro.gemie.service.impl;

import ch.emfinfopro.gemie.entity.BookingHistory;
import ch.emfinfopro.gemie.repository.BookingHistoryRepository;
import ch.emfinfopro.gemie.service.BookingHistoryService;
import ch.emfinfopro.gemie.service.DeviceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;

@Service
public class BookingHistoryServiceImpl implements BookingHistoryService {

    @Autowired
    BookingHistoryRepository bookingHistoryRepository;

    @Autowired
    DeviceService deviceService;

    // =====================
    //         GET
    // =====================

    public BookingHistory save(BookingHistory bookingHistory) {
        return bookingHistoryRepository.save(bookingHistory);
    }

    @Override
    public String getDeviceAvailability(Integer deviceId, Date startDate, Date endDate) {
        String availableDate = null;
        List<BookingHistory> bookingHistory = bookingHistoryRepository.findBookingHistoryByDeviceIdAndReturnDateIsNull(deviceId);

        if (bookingHistory.isEmpty()) {
            return availableDate;
        }

        for (BookingHistory deviceBookingLine : bookingHistory) {
            if ((startDate.before(deviceBookingLine.getBooking().getStartDate())  || startDate.equals(deviceBookingLine.getBooking().getStartDate())) && endDate.after(deviceBookingLine.getBooking().getStartDate())) {
                availableDate = deviceBookingLine.getBooking().getEstimateEndDate().toInstant().plus(1, ChronoUnit.DAYS).plus(2, ChronoUnit.HOURS).toString().substring(0, 10);
            }
            if ((startDate.after(deviceBookingLine.getBooking().getStartDate()) || startDate.equals(deviceBookingLine.getBooking().getStartDate())) && (startDate.before(deviceBookingLine.getBooking().getEstimateEndDate()))) {
                availableDate = deviceBookingLine.getBooking().getEstimateEndDate().toInstant().plus(1, ChronoUnit.DAYS).plus(2, ChronoUnit.HOURS).toString().substring(0, 10);
            }
        }

        return availableDate;
    }


    // =====================
    //         SAVE
    // =====================


    // =====================
    //         DELETE
    // =====================

}
