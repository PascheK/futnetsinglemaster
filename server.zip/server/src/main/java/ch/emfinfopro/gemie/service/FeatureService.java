package ch.emfinfopro.gemie.service;

import ch.emfinfopro.gemie.dto.post.PostFeature;
import ch.emfinfopro.gemie.entity.Device;
import ch.emfinfopro.gemie.entity.Feature;

import java.util.List;

public interface FeatureService {

    // =====================
    //         GET
    // =====================

    /**
     * Get all features
     * return list of features
     */
    List<Feature> getFeatures();

    Feature getFeature(Integer id);

    // =====================
    //         SAVE
    // =====================

    Feature saveFeature(PostFeature feature, Device device);

    // =====================
    //         DELETE
    // =====================

    void deleteFeaturesByDevice(Device device);

    void deleteFeature(Integer id);

}

