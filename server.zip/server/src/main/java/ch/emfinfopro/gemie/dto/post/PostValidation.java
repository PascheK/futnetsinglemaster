package ch.emfinfopro.gemie.dto.post;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class PostValidation {
    private Integer bookingId;
    private List<Integer> devicesIds;
    private boolean validation;
}
