package ch.emfinfopro.gemie.dto.get;

import ch.emfinfopro.gemie.entity.Booking;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class ListBooking {
    private Integer id;
    private String userEmail;
    private String userName;
    private String reason;
    private Booking.State state;
    private Date startDate;
    private Date estimateEndDate;
    private List<InfoBookingDevice> devices;
}
