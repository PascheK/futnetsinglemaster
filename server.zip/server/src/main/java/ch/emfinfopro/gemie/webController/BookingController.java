package ch.emfinfopro.gemie.webController;

import ch.emfinfopro.gemie.dto.get.ListBooking;
import ch.emfinfopro.gemie.dto.post.PostBooking;
import ch.emfinfopro.gemie.dto.post.PostReturnDevices;
import ch.emfinfopro.gemie.dto.post.PostValidation;
import ch.emfinfopro.gemie.entity.Booking;
import ch.emfinfopro.gemie.service.BookingService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller for the booking entity
 *
 * @author Paulo Venancio Jordao
 * @version 2.0
 */
@CrossOrigin
@RestController
@RequestMapping("/booking")
@SecurityRequirement(name = "token")
public class BookingController {

    @Autowired
    BookingService bookingService;

    // =====================
    //         GET
    // =====================

    @GetMapping(value = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<ListBooking> getBookings() {
        return bookingService.getBookings();
    }

    @GetMapping(value = "/user", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<ListBooking> getBookingsByUser() {
        return bookingService.getBookingsByUser();
    }

    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Booking getBooking(@PathVariable Integer id) {
        return bookingService.getBooking(id);
    }

    @GetMapping(value = "/states", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Booking.State> getStates() {
        return bookingService.getStates();
    }


    // =====================
    //         POST 
    // =====================   

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Booking saveBooking(@RequestBody PostBooking booking) {
        return bookingService.saveBooking(booking);
    }

    @PostMapping(value = "validate", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Booking validateBooking(@RequestBody PostValidation validation) {
        return bookingService.validateBooking(validation);
    }


    // =====================
    //         PUT 
    // =====================   

    @PutMapping(value = "return", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ListBooking returnDevices(@RequestBody PostReturnDevices returnDevices) {
        return bookingService.returnDevices(returnDevices);
    }

    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
      public Booking updateBooking(@PathVariable Integer id, @RequestBody PostBooking booking) {
            return bookingService.updateBooking(id, booking);
        }


}
