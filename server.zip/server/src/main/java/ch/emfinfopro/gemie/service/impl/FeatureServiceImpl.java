package ch.emfinfopro.gemie.service.impl;

import ch.emfinfopro.gemie.dto.post.PostFeature;
import ch.emfinfopro.gemie.entity.Device;
import ch.emfinfopro.gemie.entity.Feature;
import ch.emfinfopro.gemie.entity.User;
import ch.emfinfopro.gemie.exception.FeatureNotFoundException;
import ch.emfinfopro.gemie.repository.FeatureRepository;
import ch.emfinfopro.gemie.service.FeatureService;
import ch.emfinfopro.gemie.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FeatureServiceImpl implements FeatureService {

    @Autowired
    FeatureRepository featureRepository;

    @Autowired
    UserService userService;

    // =====================
    //         GET
    // =====================

    @Override
    /**
     * Get all features
     * return list of features
     */
    public List<Feature> getFeatures() {
        return (List<Feature>) featureRepository.findAll();
    }

    @Override
    /**
     * Get a feature by id
     * @param id
     * @return Feature
     */
    public Feature getFeature(Integer id) {
        Optional<Feature> feature = featureRepository.findById(id);
        if (feature.isPresent()) {
            return feature.get();
        } else {
            throw new FeatureNotFoundException(id);
        }
    }

    // =====================
    //         SAVE
    // =====================


    @Override
    /**
     * Save a new feature
     * @param feature
     * @return the saved feature
     */
    public Feature saveFeature(PostFeature feature, Device device) {
        User connectedUser = userService.getConnectedUser();
        Logger logger = LoggerFactory.getLogger(FeatureServiceImpl.class);
        logger.info("INSERT - Feature : '{}' on device '{}' by '{}' ('{}')", feature.getValue(), device.getInventoryNumber(), connectedUser.getName(), connectedUser.getEmail());

        return featureRepository.save(mapToEntity(feature, device));
    }

    // =====================
    //         DELETE
    // =====================

    @Override
    /**
     * Delete a feature
     * @param id
     */
    public void deleteFeature(Integer id) {
        featureRepository.deleteById(id);
    }

    /**
     * Delete a feature by device id
     * @param device
     */
    public void deleteFeaturesByDevice(Device device) {
        featureRepository.deleteByDevice(device);
    }


    // =====================
    //         UTILS
    // =====================

    /**
     * Map a PostFeature to a Feature
     * @param feature
     * @return Feature
     */
    private Feature mapToEntity(PostFeature feature, Device device) {
        Feature featureToSave = new Feature();
        featureToSave.setLabel(feature.getLabel());
        featureToSave.setValue(feature.getValue());
        featureToSave.setDevice(device);
        return featureToSave;
    }

}
