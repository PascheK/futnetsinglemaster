package ch.emfinfopro.gemie.service.impl;

import ch.emfinfopro.gemie.dto.get.DateOfBooking;
import ch.emfinfopro.gemie.dto.get.InfoDevice;
import ch.emfinfopro.gemie.dto.get.InfoType;
import ch.emfinfopro.gemie.dto.get.ListDevice;
import ch.emfinfopro.gemie.dto.post.PostDevice;
import ch.emfinfopro.gemie.dto.post.PostFeature;
import ch.emfinfopro.gemie.entity.*;
import ch.emfinfopro.gemie.exception.DeviceNotFoundException;
import ch.emfinfopro.gemie.exception.ForbiddenException;
import ch.emfinfopro.gemie.exception.UserNotModeratorException;
import ch.emfinfopro.gemie.repository.DeviceRepository;
import ch.emfinfopro.gemie.service.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;


@Service
public class DeviceServiceImpl implements DeviceService {

    @Autowired
    DeviceRepository deviceRepository;

    @Autowired
    ModelService modelService;

    @Autowired
    TypeService typeService;

    @Autowired
    RoomService roomService;

    @Autowired
    SectionService sectionService;

    @Autowired
    SchoolService schoolService;

    @Autowired
    UserService userService;

    @Autowired
    FeatureService featureService;

    // =====================
    //         GET
    // =====================

    @Override
    public List<String> getDevicesInventoryNumber() {
        List<Device> devices = (List<Device>) deviceRepository.findAll();
        return devices.stream().map(Device::getInventoryNumber).toList();
    }

    @Override
    public List<ListDevice> getDevices() {
        List<Device> devices;
        User connectedUser = userService.getConnectedUser();
        User.Role userRole = connectedUser.getRole();
        if (userRole == User.Role.ADMIN) {
            devices = (List<Device>) deviceRepository.findAll();
        } else {
            devices = deviceRepository.findAllByRoom_Section(connectedUser.getSection());
        }
        return devices.stream().map(this::mapToDTOList).toList();
    }

    @Override
    public InfoDevice getDeviceInfo(Integer id) {
        Optional<Device> device = deviceRepository.findById(id);
        if (device.isPresent()) {
            return mapToDTOInfo(device.get());
        } else {
            throw new DeviceNotFoundException(id.toString());
        }
    }

    public Device getDevice(Integer id) {
        Optional<Device> device = deviceRepository.findById(id);
        if (device.isPresent()) {
            return device.get();
        } else {
            throw new DeviceNotFoundException(id.toString());
        }
    }

    @Override
    public InfoDevice getDeviceByInventoryNumber(String inventoryNumber) {
        Optional<Device> device = deviceRepository.findByInventoryNumber(inventoryNumber);
        if (device.isPresent()) {
            return mapToDTOInfo(device.get());
        } else {
            throw new DeviceNotFoundException(inventoryNumber);
        }
    }

    @Override
    public List<Device.State> getStates() {
        return Arrays.asList(Device.State.values());
    }

    // =====================
    //         SAVE
    // =====================

    @Override
    public Device saveDevice(PostDevice device) {
        User connectedUser = userService.getConnectedUser();

        if (connectedUser.getRole() == User.Role.USER) throw new ForbiddenException();

        Device newDevice = mapToEntity(device);
        if (deviceRepository.findByInventoryNumber(newDevice.getInventoryNumber()).isPresent()) {
            throw new IllegalArgumentException("Numéro d'inventaire déjà existant");
        }

        Device savedDevice = deviceRepository.save(newDevice);

        if (!device.getFeatures().isEmpty()) {
            for (PostFeature feature : device.getFeatures()) {
                featureService.saveFeature(feature, savedDevice);
            }
        }

        Logger logger = LoggerFactory.getLogger(DeviceServiceImpl.class);
        logger.info("INSERT - Device : '{}' by {} ({})", newDevice.getInventoryNumber(), connectedUser.getName(), connectedUser.getEmail());

        return savedDevice;
    }

    @Override
    public Device updateDevice(Integer id, PostDevice device) {
        User connectedUser = userService.getConnectedUser();

        if (connectedUser.getRole() == User.Role.USER) throw new ForbiddenException();

        Device deviceToUpdate = getDevice(id);
        deviceToUpdate.setName(device.getName());
        deviceToUpdate.setSerialNumber(device.getSerialNumber());
        deviceToUpdate.setBuyDate(device.getBuyDate());
        deviceToUpdate.setBuyPrice(device.getBuyPrice());
        deviceToUpdate.setRenewalDate(device.getRenewalDate());
        deviceToUpdate.setModeratorControl(device.getModeratorControl());
        deviceToUpdate.setModel(modelService.getModel(device.getModelId()));
        deviceToUpdate.setStorage(device.getStorageId() != null ? getDevice(device.getStorageId()) : null);
        deviceToUpdate.setType(typeService.getType(device.getTypeId()));
        deviceToUpdate.setState(device.getState());
        deviceToUpdate.setRoom(roomService.getRoom(device.getRoomId()));
        User manager = userService.getUser(device.getManagerId());
        if (manager.getRole() != User.Role.USER) {
            deviceToUpdate.setManager(manager);
        } else {
            throw new UserNotModeratorException();
        }
        
        deviceToUpdate.setModifUser(connectedUser);
        deviceToUpdate.setUpdatedAt(new Date());

        featureService.deleteFeaturesByDevice(deviceToUpdate);

        if (!device.getFeatures().isEmpty()) {
            for (PostFeature feature : device.getFeatures()) {
                featureService.saveFeature(feature, deviceToUpdate);
            }
        }

        Logger logger = LoggerFactory.getLogger(DeviceServiceImpl.class);
        logger.info("UPDATE - Device : '{}' by {} ({})", deviceToUpdate.getInventoryNumber(), connectedUser.getName(), connectedUser.getEmail());

        return deviceRepository.save(deviceToUpdate);
    }

    // =====================
    //         DELETE
    // =====================

    @Override
    public void deleteDevice(Integer id) {
        deviceRepository.deleteById(id);
    }


    // =====================
    //         UTILS
    // =====================

    // convert Entity into DTO
    public ListDevice mapToDTOList(Device device) {
        ListDevice deviceListDto = new ListDevice();
        deviceListDto.setId(device.getId());
        deviceListDto.setInventoryNumber(device.getInventoryNumber());
        deviceListDto.setName(device.getName());
        InfoType typeInfoDto = new InfoType(device.getType().getId(), device.getType().getLabel());
        deviceListDto.setType(typeInfoDto);
        deviceListDto.setState(device.getState());
        deviceListDto.setRoom(device.getRoom());
        User connectedUser = userService.getConnectedUser();
        List<DateOfBooking> datesOfBooking = device
                .getBookinghistories()
                .stream()
                .filter(bookingHistoryLine -> bookingHistoryLine.getReturnDate() == null)
                .map(bookingHistoryLine -> new DateOfBooking(
                        bookingHistoryLine
                                .getBooking()
                                .getId(),
                        bookingHistoryLine
                                .getBooking()
                                .getReason(),
                        bookingHistoryLine
                                .getBooking()
                                .getStartDate(),
                        bookingHistoryLine
                                .getBooking()
                                .getEstimateEndDate(),
                        bookingHistoryLine
                                .getBooking()
                                .getUser()
                                .getMicrosoftId()
                                .equals(connectedUser.getMicrosoftId())
                        )
                ).toList();
        deviceListDto.setUnavailableDates(datesOfBooking);
        return deviceListDto;
    }

    private InfoDevice mapToDTOInfo(Device device) {
        InfoDevice deviceInfoDto = new InfoDevice();
        deviceInfoDto.setId(device.getId());
        deviceInfoDto.setInventoryNumber(device.getInventoryNumber());
        deviceInfoDto.setName(device.getName());
        deviceInfoDto.setSerialNumber(device.getSerialNumber());
        deviceInfoDto.setBuyDate(device.getBuyDate());
        deviceInfoDto.setBuyPrice(device.getBuyPrice());
        deviceInfoDto.setRenewalDate(device.getRenewalDate());
        deviceInfoDto.setModel(device.getModel());
        deviceInfoDto.setBrand(device.getModel().getBrand());
        String storage = device.getStorage() != null ? device.getStorage().getInventoryNumber() : null;
        deviceInfoDto.setStorage(storage);
        deviceInfoDto.setType(device.getType());
        deviceInfoDto.setState(device.getState());
        deviceInfoDto.setRoom(device.getRoom());
        deviceInfoDto.setImage("https://" + ServletUriComponentsBuilder.fromCurrentContextPath().build().getHost() + "/model/img/" + device.getModel().getId());
        deviceInfoDto.setManagerId(device.getManager() != null ? device.getManager().getId() : null);
        deviceInfoDto.setManagerName(device.getManager() != null ? device.getManager().getName() : null);
        deviceInfoDto.setManagerEmail(device.getManager() != null ? device.getManager().getEmail() : null);
        deviceInfoDto.setFeatures(device.getFeatures());
        User connectedUser = userService.getConnectedUser();
        List<DateOfBooking> datesOfBooking = device
                .getBookinghistories()
                .stream()
                .filter(bookingHistoryLine -> bookingHistoryLine.getReturnDate() == null)
                .map(bookingHistoryLine -> new DateOfBooking(
                        bookingHistoryLine.getBooking().getId(),
                        bookingHistoryLine.getBooking().getReason(),
                        bookingHistoryLine.getBooking().getStartDate(),
                        bookingHistoryLine.getBooking().getEstimateEndDate(),
                        bookingHistoryLine.getBooking().getUser().getMicrosoftId().equals(connectedUser.getMicrosoftId())
                ))
                .toList();
        deviceInfoDto.setUnavailableDates(datesOfBooking);
        return deviceInfoDto;
    }

    // convert DevicePOSTDTO to entity
    private Device mapToEntity(PostDevice device) {
        Device deviceToSave = new Device();
        deviceToSave.setInventoryNumber(device.getInventoryNumber() != null ? device.getInventoryNumber() : generateInventoryNumber(device));
        deviceToSave.setName(device.getName());
        deviceToSave.setSerialNumber(device.getSerialNumber());
        deviceToSave.setBuyDate(device.getBuyDate());
        deviceToSave.setBuyPrice(device.getBuyPrice());
        deviceToSave.setRenewalDate(device.getRenewalDate());
        deviceToSave.setModeratorControl(device.getModeratorControl());
        deviceToSave.setModel(modelService.getModel(device.getModelId()));
        deviceToSave.setStorage(device.getStorageId() != null ? getDevice(device.getStorageId()) : null);
        deviceToSave.setType(typeService.getType(device.getTypeId()));
        deviceToSave.setState(device.getState());
        deviceToSave.setRoom(roomService.getRoom(device.getRoomId()));
        User manager = userService.getUser(device.getManagerId());
        if (manager.getRole() != User.Role.USER) {
            deviceToSave.setManager(manager);
        } else {
            throw new UserNotModeratorException();
        }
        User connectedUser = userService.getConnectedUser();
        deviceToSave.setModifUser(connectedUser);
        return deviceToSave;
    }

    private String generateInventoryNumber(PostDevice device) {
        //auto generate inventory number with school name-section name-room name-XXXX (XXXX = 4 digits) like "EMF-INFO-A42-0001"
        String newInventoryNumber = "";
        Room room = roomService.getRoom(device.getRoomId());
        Section section = sectionService.getSection(room.getSection().getId());
        School school = schoolService.getSchool(section.getSchool().getId());
        List<String> inventory = getDevicesInventoryNumber().stream().filter(inventoryNumber -> inventoryNumber.startsWith(school.getLabel() + "-" + section.getInitials() + "-" + room.getLabel() + "-")).sorted().toList();
        if (!inventory.isEmpty()) {
            for (int i = 0; i < inventory.size(); i++) {
                if (!inventory.get(i).equals(school.getLabel() + "-" + section.getInitials() + "-" + room.getLabel() + "-" + String.format("%04d", i))) {
                    newInventoryNumber = school.getLabel() + "-" + section.getInitials() + "-" + room.getLabel() + "-" + String.format("%04d", i);
                    break;
                }
            }
        } else {
            newInventoryNumber = school.getLabel() + "-" + section.getInitials() + "-" + room.getLabel() + "-0000";
        }
        return newInventoryNumber;
    }


}
