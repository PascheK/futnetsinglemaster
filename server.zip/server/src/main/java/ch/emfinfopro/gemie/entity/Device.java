package ch.emfinfopro.gemie.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@RequiredArgsConstructor
@Entity
@Table(name = "device")
public class Device {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Size(max = 45)
    @NonNull
    @NotNull
    @Column(name = "inventory_number", nullable = false, length = 45)
    private String inventoryNumber;

    @Size(max = 45)
    @NonNull
    @NotNull
    @Column(name = "name", nullable = false, length = 45)
    private String name;


    @Size(max = 50)
    @Column(name = "serial_number", length = 50)
    private String serialNumber;

    @Size(max = 255)
    @Column(name = "comment", length = 255)
    private String comment;

    @Temporal(TemporalType.DATE)
    @Column(name = "buy_date")
    private Date buyDate;

    @Column(name = "buy_price", precision = 8, scale = 2)
    private BigDecimal buyPrice;

    @Temporal(TemporalType.DATE)
    @Column(name = "renewal_date")
    private Date renewalDate;

    @NonNull
    @NotNull
    @Column(name = "moderator_control", nullable = false)
    private Boolean moderatorControl;

    @NonNull
    @NotNull
    @ManyToOne(optional = false)
    @JoinColumn(name = "model_id", nullable = false, referencedColumnName = "id")
    private Model model;

    @NonNull
    @NotNull
    @ManyToOne(optional = false)
    @JoinColumn(name = "room_id", nullable = false, referencedColumnName = "id")
    private Room room;

    @ManyToOne
    @JoinColumn(name = "storage_id", referencedColumnName = "id")
    private Device storage;

    @NonNull
    @NotNull
    @ManyToOne(optional = false)
    @JoinColumn(name = "type_id", nullable = false, referencedColumnName = "id")
    private Type type;

    public enum State {
        OK,
        NOTOK,
        OUT,
        LIMITED,
        IN_USE
    }

    @NonNull
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "state", nullable = false)
    private State state;

    @ManyToOne
    @JoinColumn(name = "manager_id", nullable = false, referencedColumnName = "id")
    private User manager;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "inventory_date")
    private Date inventoryDate = new Date();

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "updated_at")
    private Date updatedAt = new Date();

    @ManyToOne(optional = false)
    @JoinColumn(name = "modif_user_id", referencedColumnName = "id")
    private User modifUser;

    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "device")
    private List<BookingHistory> bookinghistories;

    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "storage")
    private List<Device> devices;

    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "device")
    private List<Comment> comments;

    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "device")
    private List<Feature> features;

}