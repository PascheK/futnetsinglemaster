package ch.emfinfopro.gemie.exception;

public class ForbiddenException extends RuntimeException {
    public ForbiddenException() {
        super("Vous n'êtes pas autorisé à effectuer cette action.");
    }
}
