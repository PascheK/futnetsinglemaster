package ch.emfinfopro.gemie.service;

import ch.emfinfopro.gemie.dto.post.PostBrand;
import ch.emfinfopro.gemie.entity.Brand;

import java.util.List;

public interface BrandService {

    // =====================
    //         GET
    // =====================

    /**
     * Get all brands
     * return list of brands
     */
    List<Brand> getBrands();

    Brand getBrand(Integer id);


    // =====================
    //         SAVE 
    // =====================   

    Brand saveBrand(PostBrand brand);

    Brand updateBrand(Integer id, PostBrand brand);

    // =====================
    //         DELETE 
    // =====================   

    void deleteBrand(Integer id);

}

