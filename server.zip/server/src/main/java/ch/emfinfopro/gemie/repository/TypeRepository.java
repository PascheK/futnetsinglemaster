package ch.emfinfopro.gemie.repository;

import ch.emfinfopro.gemie.entity.Section;
import ch.emfinfopro.gemie.entity.Type;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface TypeRepository extends CrudRepository<Type, Integer> {

    List<Type> findAllByParentTypeIsNull();

    List<Type> findAllByParentTypeIsNullAndSection(Section section);

}
