package ch.emfinfopro.gemie.service;

import ch.emfinfopro.gemie.dto.get.InfoDevice;
import ch.emfinfopro.gemie.dto.get.ListDevice;
import ch.emfinfopro.gemie.dto.post.PostDevice;
import ch.emfinfopro.gemie.entity.Device;

import java.util.List;

public interface DeviceService {

    // =====================
    //         GET
    // =====================

    List<ListDevice> getDevices();

    Device getDevice(Integer id);

    InfoDevice getDeviceInfo(Integer id);

    InfoDevice getDeviceByInventoryNumber(String inventoryNumber);

    List<String> getDevicesInventoryNumber();

    List<Device.State> getStates();

    // =====================
    //         SAVE
    // =====================

    Device saveDevice(PostDevice device);

    Device updateDevice(Integer id, PostDevice device);

    // =====================
    //        DELETE
    // =====================

    void deleteDevice(Integer id);




}
