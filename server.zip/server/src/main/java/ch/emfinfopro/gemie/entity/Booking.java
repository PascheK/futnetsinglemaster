package ch.emfinfopro.gemie.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@RequiredArgsConstructor
@Entity
@Table(name = "booking")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @NotNull
    @NonNull
    @ManyToOne(optional = false)
    @JoinColumn(name = "user_id", nullable = false, referencedColumnName = "id")
    private User user;

    @NotNull
    @NonNull
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "start_date", nullable = false)
    private Date startDate;

    @NotNull
    @NonNull
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "estimate_end_date", nullable = false)
    private Date estimateEndDate;

    @Size(max = 255)
    @NonNull
    @NotNull
    @Column(name = "reason", nullable = false)
    private String reason;

    public enum State {
        FUTUR,
        IN_PROGRESS,
        IN_VALIDATION,
        DENIED,
        CANCELED,
        COMPLETE,
    }

    @NonNull
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "state", nullable = false)
    private Booking.State state;

    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY,mappedBy = "booking")
    private List<BookingHistory> bookinghistories;

}