package ch.emfinfopro.gemie.repository;

import ch.emfinfopro.gemie.entity.Comment;
import ch.emfinfopro.gemie.entity.Device;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface CommentRepository extends CrudRepository<Comment, Integer> {
    List<Comment> findByDevice(Device device);
}
