package ch.emfinfopro.gemie.exception;

public class UserNotConnectedException extends RuntimeException {
    public UserNotConnectedException() {
        super("Vous n'êtes pas connecté. Veuillez vous connecter pour effectuer cette requête.");
    }
}