package ch.emfinfopro.gemie.dto.get;

import ch.emfinfopro.gemie.entity.Device;
import ch.emfinfopro.gemie.entity.Room;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class ListDevice {
    private Integer id;
    private String inventoryNumber;
    private String name;
    private InfoType type;
    private Device.State state;
    private Room room;
    private List<DateOfBooking> unavailableDates;
}
