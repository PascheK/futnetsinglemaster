package ch.emfinfopro.gemie.repository;

import ch.emfinfopro.gemie.entity.BookingHistory;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface BookingHistoryRepository extends CrudRepository<BookingHistory, Integer> {
    List<BookingHistory> findBookingHistoryByDeviceIdAndReturnDateIsNull(Integer deviceId);

}
