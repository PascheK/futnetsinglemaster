package ch.emfinfopro.gemie.exception;

public class CommentNotFoundException extends RuntimeException {
    public CommentNotFoundException(Integer id) {
        super("Le commentaire '" + id + "' n'existe pas dans la base de données.");
    }
}
