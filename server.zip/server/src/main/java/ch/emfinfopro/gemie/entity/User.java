package ch.emfinfopro.gemie.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@RequiredArgsConstructor
@Entity
@Table(name = "user")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Size(max = 100)
    @NonNull
    @NotNull
    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @Size(max = 100)
    @NonNull
    @NotNull
    @Column(name = "email", nullable = false, length = 100)
    private String email;

    @Size(max = 100)
    @NonNull
    @NotNull
    @JsonIgnore
    @Column(name = "microsoft_id", nullable = false, length = 100)
    private String microsoftId;

    @Size(max = 50)
    @Column(name = "phone", length = 50)
    private String phone;

    @NonNull
    @NotNull
    @Column(name = "active", nullable = false)
    private Boolean active = false;


    public enum Role {
        ADMIN,
        MODO,
        USER
    }

    @NonNull
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "role", nullable = false)
    private User.Role role;


    @ManyToOne(optional = false)
    @JoinColumn(name = "section_id", nullable = false, referencedColumnName = "id")
    private Section section;

    @JsonIgnore
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "last_login")
    private Date lastLogin;

    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "manager")
    private List<Device> managedDevices;

    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "modifUser")
    private List<Device> modifiedDevices;

    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
    private List<Comment> comments;

    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
    private List<Booking> bookings;

}