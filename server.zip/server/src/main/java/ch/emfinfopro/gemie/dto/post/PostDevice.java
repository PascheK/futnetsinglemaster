package ch.emfinfopro.gemie.dto.post;

import ch.emfinfopro.gemie.entity.Device;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.lang.Nullable;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class PostDevice {
    @Nullable
    private String inventoryNumber;
    private String name;
    private String serialNumber;
    private Date buyDate;
    private BigDecimal buyPrice;
    private Date renewalDate;
    private Integer modelId;
    @Nullable
    private Integer storageId;
    private Integer typeId;
    private Device.State state;
    private Boolean moderatorControl;
    private Integer roomId;
    private Integer managerId;
    private List<PostFeature> features;
}
