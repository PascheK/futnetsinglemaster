package ch.emfinfopro.gemie.security;

import ch.emfinfopro.gemie.service.SectionService;
import ch.emfinfopro.gemie.service.UserService;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.oauth2.server.resource.OAuth2ResourceServerConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserService;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import java.util.HashSet;
import java.util.Set;


@Configuration
public class ApplicationConfiguration {

    @Bean
    public ModelMapper modelMapper() {
        return new ModelMapper();
    }

    @Bean
    public AuthenticationSuccessHandler myAuthenticationSuccessHandler(UserService userService, SectionService sectionService) {
        return new MySimpleUrlAuthenticationSuccessHandler(userService, sectionService);
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http, UserService userService, SectionService sectionService) throws Exception {

        OidcUserService microsoftUserService = new OidcUserService();
        Set<String> microsoftScopes = new HashSet<>();
        microsoftScopes.add("https://graph.microsoft.com/SCOPE_User.Read.All");
//        microsoftScopes.add("https://graph.microsoft.com/SCOPE_User.Read");

        microsoftUserService.setAccessibleScopes(microsoftScopes);

        http
                .cors()
                .and()
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .authorizeHttpRequests(configurer ->
                        configurer
                                .requestMatchers("/swagger-ui/**", "/api-docs/**" ,"/index.html", "/", "/model/img/*").permitAll()
                                .anyRequest()
                                .authenticated()
                )
                .oauth2ResourceServer(OAuth2ResourceServerConfigurer::jwt)
                .oauth2Login(oauthLogin -> oauthLogin.userInfoEndpoint()
                        .oidcUserService(microsoftUserService)
                        .and()
                        .successHandler(myAuthenticationSuccessHandler(userService, sectionService)));

        return http.build();
    }

    @Bean
        public OpenAPI springShopOpenAPI() {
            return new OpenAPI()
                    .info(new Info().title("GEMIE API")
                            .description("API de gestion de l'inventaire de l'École des Métiers de Fribourg")
                            .version("v2.0.0 BETA"))
                    .components(new Components()
                            .addSecuritySchemes("token",
                                    new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("bearer").bearerFormat("JWT")));
        }


}
