package ch.emfinfopro.gemie.dto.post;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.lang.Nullable;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class PostType {
    private String label;
    @Nullable
    private Integer parentTypeId;
}
