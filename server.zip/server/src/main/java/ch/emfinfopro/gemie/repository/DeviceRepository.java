package ch.emfinfopro.gemie.repository;

import ch.emfinfopro.gemie.entity.Device;
import ch.emfinfopro.gemie.entity.Section;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface DeviceRepository extends CrudRepository<Device, Integer> {

    Optional<Device> findByInventoryNumber(String inventoryNumber);

    List<Device> findAllByRoom_Section(Section section);

}
