package ch.emfinfopro.gemie.service;

import ch.emfinfopro.gemie.dto.post.PostComment;
import ch.emfinfopro.gemie.entity.Comment;

import java.util.List;

public interface CommentService {

    // =====================
    //         GET
    // =====================

    /**
     * Get all comments
     * return list of comments
     */
    List<Comment> getComments();

    Comment getComment(Integer id);

    List<Comment> getCommentsByDevice(Integer deviceId);


    // =====================
    //         SAVE 
    // =====================   

    Comment saveComment(PostComment comment);

    Comment updateComment(Integer id, PostComment comment);

    // =====================
    //         DELETE 
    // =====================   

    void deleteComment(Integer id);


}

