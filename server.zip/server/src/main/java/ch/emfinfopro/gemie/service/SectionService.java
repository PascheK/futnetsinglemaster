package ch.emfinfopro.gemie.service;

import ch.emfinfopro.gemie.entity.Section;

import java.util.List;

public interface SectionService {

    // =====================
    //         GET
    // =====================

    List<Section> getSections();

    Section getSection(Integer id);

    // =====================
    //         SAVE 
    // =====================   

    Section saveSection(Section section);

    // =====================
    //         DELETE 
    // =====================   

    void deleteSection(Integer id);

}
