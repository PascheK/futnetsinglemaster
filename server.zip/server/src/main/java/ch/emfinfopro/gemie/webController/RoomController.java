package ch.emfinfopro.gemie.webController;

import ch.emfinfopro.gemie.dto.post.PostRoom;
import ch.emfinfopro.gemie.entity.Room;
import ch.emfinfopro.gemie.service.RoomService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller for the room entity
 *
 * @author Paulo Venancio Jordao
 * @version 2.0
 */
@CrossOrigin
@RestController
@RequestMapping("/room")
@SecurityRequirement(name = "token")
public class RoomController {

    @Autowired
    RoomService roomService;

    // =====================
    //         GET
    // =====================

    /**
     * Get all rooms
     *
     * @return List of rooms
     */
    @GetMapping(value = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Room> getRooms() {
        return roomService.getRooms();
    }

    /**
     * Get a room by id
     *
     * @param id Room id
     * @return Room
     */
    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Room getRoom(@PathVariable Integer id) {
        return roomService.getRoom(id);
    }

    // =====================
    //         POST 
    // =====================

    /**
     * Save a room
     *
     * @param Room to save
     * @return Room saved
     */
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Room saveRoom(@RequestBody PostRoom room) {
        return roomService.saveRoom(room);
    }

    // =====================
    //         PUT
    // =====================

    /**
     * Update a room
     *
     * @param id to update
     * @param room to update
     * @return Room updated
     */
    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Room updateType(@PathVariable Integer id, @RequestBody PostRoom room) {
        return roomService.updateRoom(id, room);
    }
}
