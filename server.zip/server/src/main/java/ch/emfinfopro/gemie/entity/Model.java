package ch.emfinfopro.gemie.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@RequiredArgsConstructor
@Entity
@Table(name = "model")
public class Model {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Size(max = 50)
    @NonNull
    @NotNull
    @Column(name = "name", nullable = false, length = 50)
    private String label;

    @Size(max = 30)
    @Column(name = "color", length = 30)
    private String color;

    @NonNull
    @NotNull
    @ManyToOne(optional = false)
    @JoinColumn(name = "brand_id", nullable = false)
    private Brand brand;

    @JsonIgnore
    @Lob
    @Column(name = "img", columnDefinition="MEDIUMBLOB")
    private byte[] img;

    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY,mappedBy = "model")
    private List<Device> devices;

}