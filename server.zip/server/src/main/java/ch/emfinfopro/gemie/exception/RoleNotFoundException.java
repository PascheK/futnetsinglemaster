package ch.emfinfopro.gemie.exception;

public class RoleNotFoundException  extends RuntimeException {
    public RoleNotFoundException(int id) {
        super("Le role '" + id + "' n'existe pas dans la base de données.");
    }
}
