package ch.emfinfopro.gemie.exception;

public class DeviceNotFoundException extends RuntimeException {
    public DeviceNotFoundException(String id) {
        super("L'appareil '" + id + "' n'existe pas dans la base de données.");
    }
}
