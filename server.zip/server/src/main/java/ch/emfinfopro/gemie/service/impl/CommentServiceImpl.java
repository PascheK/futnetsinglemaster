package ch.emfinfopro.gemie.service.impl;

import ch.emfinfopro.gemie.dto.post.PostComment;
import ch.emfinfopro.gemie.entity.Comment;
import ch.emfinfopro.gemie.entity.Device;
import ch.emfinfopro.gemie.entity.User;
import ch.emfinfopro.gemie.exception.CommentNotFoundException;
import ch.emfinfopro.gemie.exception.ForbiddenException;
import ch.emfinfopro.gemie.repository.CommentRepository;
import ch.emfinfopro.gemie.service.CommentService;
import ch.emfinfopro.gemie.service.DeviceService;
import ch.emfinfopro.gemie.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class CommentServiceImpl implements CommentService {

    @Autowired
    CommentRepository commentRepository;

    @Autowired
    UserService userService;

    @Autowired
    DeviceService deviceService;
    

    // =====================
    //         GET
    // =====================

    @Override
    /**
     * Get all comments
     * return list of comments
     */
    public List<Comment> getComments() {
        return (List<Comment>) commentRepository.findAll();
    }

    @Override
    /**
     * Get a comment by id
     * @param id
     * @return Comment
     */
    public Comment getComment(Integer id) {
        Optional<Comment> comment = commentRepository.findById(id);
        if (comment.isPresent()) {
            return comment.get();
        } else {
            throw new CommentNotFoundException(id);
        }
    }

    @Override
    public List<Comment> getCommentsByDevice(Integer deviceId) {
        Device device = deviceService.getDevice(deviceId);
        return commentRepository.findByDevice(device);
    }


    // =====================
    //         SAVE
    // =====================


    @Override
    /**
     * Save a new comment
     * @param comment
     * @return the saved comment
     */
    public Comment saveComment(PostComment comment) {
        User connectedUser = userService.getConnectedUser();
        Logger logger = LoggerFactory.getLogger(CommentServiceImpl.class);
        logger.info("INSERT - Comment : On device '{}' by {} ({})", comment.getDeviceID(), connectedUser.getName(), connectedUser.getEmail());
        return commentRepository.save(mapToEntity(comment));
    }

    @Override
    public Comment updateComment(Integer id, PostComment comment) {
        User connectedUser = userService.getConnectedUser();
        Comment commentToUpdate = getComment(id);

        if (connectedUser.getId() != commentToUpdate.getUser().getId()) throw new ForbiddenException();

        Logger logger = LoggerFactory.getLogger(CommentServiceImpl.class);
        logger.info("UPDATE - Comment : '{}' by {} ({})", id, connectedUser.getName(), connectedUser.getEmail());

        commentToUpdate.setComment(comment.getComment());
        commentToUpdate.setDevice(deviceService.getDevice(comment.getDeviceID()));
        commentToUpdate.setUser(userService.getUser(comment.getUserID()));
        return commentRepository.save(commentToUpdate);
    }

    // =====================
    //         DELETE
    // =====================

    @Override
    /**
     * Delete a comment
     * @param id
     */
    public void deleteComment(Integer id) {
        commentRepository.deleteById(id);
    }

    // =====================
    //         UTILS
    // =====================

    /**
     * Map a PostComment to a Comment
     * @param comment
     * @return Comment
     */
    private Comment mapToEntity(PostComment comment) {
        Comment commentToSave = new Comment();
        commentToSave.setComment(comment.getComment());
        commentToSave.setDevice(deviceService.getDevice(comment.getDeviceID()));
        commentToSave.setUser(userService.getUser(comment.getUserID()));
        commentToSave.setDate(new Date());
        return commentToSave;
    }

}
