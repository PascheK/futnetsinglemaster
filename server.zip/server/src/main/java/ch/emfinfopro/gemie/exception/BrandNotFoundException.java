package ch.emfinfopro.gemie.exception;

public class BrandNotFoundException extends RuntimeException {
    public BrandNotFoundException(int id) {
        super("La marque '" + id + "' n'existe pas dans la base de données.");
    }
}


