package ch.emfinfopro.gemie.exception;

public class UserNotAdminException extends RuntimeException {
    public UserNotAdminException() {
        super("L'utilisateur n'est pas administrateur.");
    }
}
