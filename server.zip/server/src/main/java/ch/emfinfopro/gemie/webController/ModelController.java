package ch.emfinfopro.gemie.webController;

import ch.emfinfopro.gemie.dto.post.PostModel;
import ch.emfinfopro.gemie.entity.Model;
import ch.emfinfopro.gemie.service.ModelService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * Controller for the model entity
 *
 * @author Paulo Venancio Jordao
 * @version 2.0
 */
@CrossOrigin
@RestController
@RequestMapping("/model")
public class ModelController {

    @Autowired
    ModelService modelService;

    // =====================
    //         GET
    // =====================

    /**
     * Get all models
     *
     * @return List of models
     */
    @Operation(security = { @SecurityRequirement(name = "token")})
    @GetMapping(value = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Model> getModels() {
        return modelService.getModels();
    }

    /**
     * Get a model by id
     *
     * @param id
     * @return
     */
    @Operation(security = { @SecurityRequirement(name = "token")})
    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Model getModel(@PathVariable Integer id) {
        return modelService.getModel(id);
    }

    /**
     * Get model img by id
     *
     * @param id
     * @return List of models
     */
    @GetMapping(value = "/img/{id}", produces = MediaType.IMAGE_JPEG_VALUE)
    public byte[] getImg(@PathVariable Integer id) {
        return modelService.getImg(id);
    }

    // =====================
    //         POST 
    // =====================

    /**
     * Save a model
     *
     * @param model
     * @return
     */
    @Operation(security = { @SecurityRequirement(name = "token")})
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Model saveModel(@RequestBody PostModel model) {
        return modelService.saveModel(model);
    }

    // =====================
    //         PUT 
    // =====================

    /**
     * Update a model
     *
     * @param model
     * @return
     */
    @Operation(security = { @SecurityRequirement(name = "token")})
    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Model updateModel(@PathVariable Integer id, @RequestBody PostModel model) {
        return modelService.updateModel(id, model);
    }

    @Operation(security = { @SecurityRequirement(name = "token")})
    @PutMapping(value = "/img/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Model updateImage(@PathVariable Integer id, @RequestParam("image") MultipartFile image) {
        return modelService.updateImage(id, image);
    }

}
