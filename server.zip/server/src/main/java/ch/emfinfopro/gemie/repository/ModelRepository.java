package ch.emfinfopro.gemie.repository;

import ch.emfinfopro.gemie.entity.Model;
import org.springframework.data.repository.CrudRepository;

public interface ModelRepository extends CrudRepository<Model, Integer> {
}
