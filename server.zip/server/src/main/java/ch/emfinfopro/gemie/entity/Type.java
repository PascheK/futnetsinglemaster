package ch.emfinfopro.gemie.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@RequiredArgsConstructor
@Entity
@Table(name = "type")
public class Type {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Size(max = 50)
    @NonNull
    @NotNull
    @Column(name = "type", nullable = false, length = 50)
    private String label;

    @JsonIgnore
    @ManyToOne(optional = true)
    @JoinColumn(name = "parent_type_id", referencedColumnName = "id")
    private Type parentType;

    @JsonIgnore
    @NonNull
    @NotNull
    @ManyToOne(optional = false)
    @JoinColumn(name = "section_id", nullable = false)
    private Section section;

    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY,mappedBy = "type")
    private List<Device> devices;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @OneToMany(fetch = FetchType.LAZY,mappedBy = "parentType", cascade = CascadeType.ALL)
    private List<Type> children;

}