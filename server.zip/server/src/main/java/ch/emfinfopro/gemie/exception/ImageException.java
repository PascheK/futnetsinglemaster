package ch.emfinfopro.gemie.exception;

public class ImageException extends RuntimeException {
    public ImageException() {
        super("L'image envoyé au serveur n'a pas pu être traitée.");
    }
}
