package ch.emfinfopro.gemie.service.impl;

import ch.emfinfopro.gemie.entity.School;
import ch.emfinfopro.gemie.exception.SchoolNotFoundException;
import ch.emfinfopro.gemie.repository.SchoolRepository;
import ch.emfinfopro.gemie.service.SchoolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SchoolServiceImpl implements SchoolService {

    @Autowired
    SchoolRepository schoolRepository;

    // =====================
    //         GET
    // =====================

    @Override
    public List<School> getSchools() {
        return (List<School>) schoolRepository.findAll();
    }

    @Override
    public School getSchool(Integer id) {
        Optional<School> school = schoolRepository.findById(id);
        if (school.isPresent()) {
            return school.get();
        } else {
            throw new SchoolNotFoundException(id);
        }
    }

    // =====================
    //         SAVE
    // =====================

    @Override
    public School saveSchool(School school) {
        return schoolRepository.save(school);
    }

    // =====================
    //         DELETE
    // =====================

    @Override
    public void deleteSchool(Integer id) {
        schoolRepository.deleteById(id);
    }


}
