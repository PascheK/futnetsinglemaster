package ch.emfinfopro.gemie.service;

import ch.emfinfopro.gemie.dto.get.ListBooking;
import ch.emfinfopro.gemie.dto.post.PostBooking;
import ch.emfinfopro.gemie.dto.post.PostReturnDevices;
import ch.emfinfopro.gemie.dto.post.PostValidation;
import ch.emfinfopro.gemie.entity.Booking;

import java.util.List;

public interface BookingService {

    // =====================
    //         GET
    // =====================

    List<ListBooking> getBookings();

    List<ListBooking> getBookingsByUser();

    Booking getBooking(Integer id);

    List<Booking.State> getStates();

    // =====================
    //         SAVE
    // =====================

    Booking saveBooking(PostBooking booking);

    Booking validateBooking(PostValidation validation);

    ListBooking returnDevices(PostReturnDevices returnDevices);

    Booking updateBooking(Integer id, PostBooking booking);

    // =====================
    //        DELETE
    // =====================

    void deleteBooking(Integer id);


}
