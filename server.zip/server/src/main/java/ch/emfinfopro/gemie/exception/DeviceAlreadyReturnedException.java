package ch.emfinfopro.gemie.exception;

public class DeviceAlreadyReturnedException extends RuntimeException {
    public DeviceAlreadyReturnedException(String inventoryNumber, int bookingId) {
        super("L'appareil '" + inventoryNumber + "' a déjà été rendu pour la réservation '" + bookingId + "'.");
    }
}
