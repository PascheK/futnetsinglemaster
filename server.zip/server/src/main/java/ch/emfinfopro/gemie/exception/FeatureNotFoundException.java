package ch.emfinfopro.gemie.exception;

public class FeatureNotFoundException extends RuntimeException {
    public FeatureNotFoundException(Integer id) {
        super("La fonctionnalité '" + id + "' n'existe pas dans la base de données.");
    }
}
