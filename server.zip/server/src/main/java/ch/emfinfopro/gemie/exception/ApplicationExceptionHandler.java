package ch.emfinfopro.gemie.exception;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.Arrays;


@ControllerAdvice
public class ApplicationExceptionHandler extends ResponseEntityExceptionHandler {


    private Logger springLogger = LoggerFactory.getLogger(ApplicationExceptionHandler.class);

    @ExceptionHandler({
            BookingNotInProgressException.class,
            BrandNotFoundException.class,
            CommentNotFoundException.class,
            DeviceAlreadyReturnedException.class,
            DeviceNotAvailable.class,
            DeviceNotFoundException.class,
            FeatureNotFoundException.class,
            ModelHasNoImageException.class,
            ModelNotFoundException.class,
            RoleNotFoundException.class,
            RoomNotFoundException.class,
            SchoolNotFoundException.class,
            SectionNotFoundException.class,
            TypeNotFoundException.class,
            ImageException.class
    })
    public ResponseEntity<Object> handleResourceNotFoundException(RuntimeException ex) {
        ErrorResponse error = new ErrorResponse(Arrays.asList(ex.getMessage()));
        springLogger.error(ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(UserNotConnectedException.class)
    public ResponseEntity<Object> handleUserNotConnectedException(UserNotConnectedException ex) {
        ErrorResponse error = new ErrorResponse(Arrays.asList(ex.getMessage()));
        springLogger.error(ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<Object> handleUserNotConnectedException(UserNotFoundException ex) {
        ErrorResponse error = new ErrorResponse(Arrays.asList(ex.getMessage()));
        springLogger.error(ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(ForbiddenException.class)
    public ResponseEntity<Object> handleForbiddenException(ForbiddenException ex) {
        ErrorResponse error = new ErrorResponse(Arrays.asList(ex.getMessage()));
        springLogger.error(ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(UserNotModeratorException.class)
    public ResponseEntity<Object> handleUserNotModeratorException(UserNotModeratorException ex) {
        ErrorResponse error = new ErrorResponse(Arrays.asList(ex.getMessage()));
        springLogger.error(ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(UserNotAdminException.class)
    public ResponseEntity<Object> handleUserNotAdminException(UserNotAdminException ex) {
        ErrorResponse error = new ErrorResponse(Arrays.asList(ex.getMessage()));
        springLogger.error(ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Object> handleIllegalArgumentException(IllegalArgumentException ex) {
        ErrorResponse error = new ErrorResponse(Arrays.asList(ex.getMessage()));
        springLogger.error(ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(NullPointerException.class)
    public ResponseEntity<Object> handleIllegalArgumentException(NullPointerException ex) {
        ErrorResponse error = new ErrorResponse(Arrays.asList(ex.getMessage()));
        springLogger.error(ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }


    @ExceptionHandler(EmptyResultDataAccessException.class)
    public ResponseEntity<Object> handleDataAccessException(EmptyResultDataAccessException ex) {
        ErrorResponse error = new ErrorResponse(Arrays.asList("Cannot delete non-existing resource"));
        springLogger.error(ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<Object> handleDataIntegrityViolationException(DataIntegrityViolationException ex) {
        ErrorResponse error = new ErrorResponse(Arrays.asList("Data Integrity Violation: we cannot process your request."));
        springLogger.error(ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ErrorResponse> handleAccessDeniedException(AccessDeniedException ex){
        ErrorResponse error = new ErrorResponse(Arrays.asList(ex.getMessage()));
        springLogger.error(ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(HttpClientErrorException.Unauthorized.class)
    public ResponseEntity<ErrorResponse> handleUnauthorizedException(HttpClientErrorException.Unauthorized ex){
        ErrorResponse error = new ErrorResponse(Arrays.asList(ex.getMessage()));
        springLogger.error(ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.UNAUTHORIZED);
    }




}
