package ch.emfinfopro.gemie.dto.get;

import ch.emfinfopro.gemie.entity.Booking;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class DateOfBooking {
    private Integer id_booking;
    private String reason;
    private Date startDate;
    private Date endDate;
    private Boolean isConnectedUser;
}
