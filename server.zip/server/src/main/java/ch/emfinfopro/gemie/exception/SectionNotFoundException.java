package ch.emfinfopro.gemie.exception;

public class SectionNotFoundException extends RuntimeException {
    public SectionNotFoundException(int id) {
        super("La section '" + id + "' n'existe pas dans la base de données.");
    }
}
