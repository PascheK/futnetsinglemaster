package ch.emfinfopro.gemie.security;

import ch.emfinfopro.gemie.entity.User;
import ch.emfinfopro.gemie.service.SectionService;
import ch.emfinfopro.gemie.service.UserService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.apache.qpid.proton.codec.security.SaslOutcomeType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.security.web.WebAttributes;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import java.io.IOException;
import java.util.Date;
import java.util.Objects;

public class MySimpleUrlAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

    @Value("${target.url}")
    private String targetUrl;

    @Value("${cookie.domain-url}")
    private String domainUrl;

    private UserService userService;

    private SectionService sectionService;

    public MySimpleUrlAuthenticationSuccessHandler(UserService userService, SectionService sectionService) {
        this.userService = userService;
        this.sectionService = sectionService;
    }

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
        handle(response, authentication);
        clearAuthenticationAttributes(request);
    }

    protected void handle(HttpServletResponse response, Authentication authentication) throws IOException {
        Logger logger = LoggerFactory.getLogger(ApplicationConfiguration.class);

        if (authentication.getPrincipal() instanceof OidcUser oidcUser) {



            User user = userService.getUserByMicrosoftId(oidcUser.getSubject());
            if (Objects.isNull(user)) {
                //TODO: vérifier que l'utilisateur est bien dans l'école des métiers
                user = new User();
                user.setMicrosoftId(oidcUser.getSubject());
                user.setName(oidcUser.getFullName());
                user.setEmail(oidcUser.getPreferredUsername());
                if (user.getEmail().endsWith("@edufr.ch")) {
                    user.setRole(User.Role.MODO);
                } else {
                    user.setRole(User.Role.USER);
                }

                //Section par défaut pour les nouveaux utilisateurs (section 1 = informatique)
                user.setSection(sectionService.getSection(1));

                user.setActive(true);
                user.setLastLogin(new Date());
                userService.registerUser(user);

                logger.info("New user registered: {} ({})", user.getName(), user.getEmail());
            }

            Cookie cookie = new Cookie("token", oidcUser.getIdToken().getTokenValue());
            cookie.setPath("/");
            cookie.setDomain(domainUrl);
            cookie.setSecure(true);
            cookie.setMaxAge(60 * 60);
            response.addCookie(cookie);

            logger.info("User logged in: {} ({})", user.getName(), user.getEmail());
        }


        if (response.isCommitted()) {
            logger.error("Can't redirect");
            return;
        }

        response.sendRedirect(targetUrl);
    }


    protected void clearAuthenticationAttributes(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            return;
        }
        session.removeAttribute(WebAttributes.AUTHENTICATION_EXCEPTION);
    }

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, FilterChain chain, Authentication authentication) throws IOException, ServletException {
        AuthenticationSuccessHandler.super.onAuthenticationSuccess(request, response, chain, authentication);
    }
}
