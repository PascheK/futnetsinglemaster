package ch.emfinfopro.gemie.service;

import ch.emfinfopro.gemie.entity.School;

import java.util.List;

public interface SchoolService {

    // =====================
    //         GET
    // =====================

    List<School> getSchools();

    School getSchool(Integer id);

    // =====================
    //         SAVE 
    // =====================   

    School saveSchool(School school);

    // =====================
    //         DELETE 
    // =====================   

    void deleteSchool(Integer id);

}
