package ch.emfinfopro.gemie.service;

import ch.emfinfopro.gemie.dto.post.PostRoom;
import ch.emfinfopro.gemie.entity.Room;

import java.util.List;

public interface RoomService {


    // =====================
    //         GET
    // =====================

    List<Room> getRooms();

    Room getRoom(Integer id);

    // =====================
    //         SAVE 
    // =====================   

    Room saveRoom(PostRoom room);

    Room updateRoom(Integer id, PostRoom room);

    // =====================
    //         DELETE 
    // =====================   

    void deleteRoom(Integer id);

}
