package ch.emfinfopro.gemie.dto.post;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class PostFeature {
    private String label;
    private String value;
}
