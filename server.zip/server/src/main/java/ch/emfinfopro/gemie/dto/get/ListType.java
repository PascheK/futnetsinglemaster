package ch.emfinfopro.gemie.dto.get;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.lang.Nullable;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class ListType {
    private Integer id;
    private String label;
    @Nullable
    private Integer parentId;
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private List<ListType> children;
}
