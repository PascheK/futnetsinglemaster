package ch.emfinfopro.gemie.service.impl;

import ch.emfinfopro.gemie.dto.post.PostUser;
import ch.emfinfopro.gemie.entity.Section;
import ch.emfinfopro.gemie.entity.User;
import ch.emfinfopro.gemie.exception.*;
import ch.emfinfopro.gemie.repository.UserRepository;
import ch.emfinfopro.gemie.service.SectionService;
import ch.emfinfopro.gemie.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UserRepository userRepository;

    @Autowired
    SectionService sectionService;


    // =====================
    //         GET
    // =====================

    @Override
    public List<User> getUsers() {
        User connectedUser = getConnectedUser();

        if (connectedUser.getRole() == User.Role.USER) throw new ForbiddenException();

        return (List<User>) userRepository.findAll();
    }

    @Override
    public User getUser(Integer id) {
        User connectedUser = getConnectedUser();
        Optional<User> user = userRepository.findById(id);
        User initUser;

        if (user.isEmpty()) throw new UserNotFoundException(id.toString());

        initUser = user.get();

        if (connectedUser.getRole() == User.Role.USER && initUser.getId() != connectedUser.getId())
            throw new ForbiddenException();

        return initUser;
    }

    @Override
    public User getUserByMicrosoftId(String id) {
        Optional<User> user = userRepository.findByMicrosoftId(id);
        User initUser = null;
        if (user.isPresent()) {
            initUser = user.get();
        }
        return initUser;
    }

    @Override
    public List<User.Role> getRoles() {
        return Arrays.asList(User.Role.values());
    }



    @Override
    public Map<String, Object> getUserClaims() {
        Authentication authentication = SecurityContextHolder.getContext()
                .getAuthentication();
        if (authentication.getPrincipal() instanceof OidcUser principal) {
            return principal.getClaims();
        }
        return Collections.emptyMap();
    }

    @Override
    public User getConnectedUser() {
        Authentication authentication = SecurityContextHolder.getContext()
                .getAuthentication();
        String microsoftId = null;
        if (authentication.getPrincipal() instanceof Jwt principal) {
            microsoftId = principal.getSubject();
        }
        if (microsoftId != null) {
             User connectedUser = getUserByMicrosoftId(microsoftId);
             if (connectedUser != null) {
                 return connectedUser;
             } else {
                 throw new UserNotFoundException(microsoftId);
             }
        } else {
            throw new UserNotConnectedException();
        }
    }

    // =====================
    //         SAVE
    // =====================

    @Override
    public User registerUser(User user) {
        return userRepository.save(user);
    }

    @Override
    public User updateUser(Integer id, PostUser user) {
        User connectedUser = getConnectedUser();
        User.Role roleConnectedUser = connectedUser.getRole();
        User userToUpdate = getUser(id);

        if ((roleConnectedUser != User.Role.USER) && (!userToUpdate.getId().equals(connectedUser.getId()))) {
            if (user.getPhone() != null) userToUpdate.setPhone(user.getPhone());
            userToUpdate.setActive(user.isActive());
            if (user.getRole() != null) userToUpdate.setRole(user.getRole());
            if (user.getSectionId() != null) {
                Section section = sectionService.getSection(user.getSectionId());
                userToUpdate.setSection(section);
            }

            Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);
            logger.info("UPDATE - User : '{}' by {} ({})", id, connectedUser.getName(), connectedUser.getEmail());
        } else {
            throw new UserNotModeratorException();
        }

        return userRepository.save(userToUpdate);

    }

    // =====================
    //         DELETE
    // =====================

    @Override
    public void deleteUser(Integer id) {
        userRepository.deleteById(id);
    }

}
