package ch.emfinfopro.gemie.service.impl;

import ch.emfinfopro.gemie.entity.Section;
import ch.emfinfopro.gemie.exception.SectionNotFoundException;
import ch.emfinfopro.gemie.repository.SectionRepository;
import ch.emfinfopro.gemie.service.SectionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SectionServiceImpl implements SectionService {

    @Autowired
    SectionRepository sectionRepository;

    // =====================
    //         GET
    // =====================

    @Override
    public List<Section> getSections() {
        return (List<Section>) sectionRepository.findAll();
    }

    @Override
    public Section getSection(Integer id) {
        Optional<Section> section = sectionRepository.findById(id);
        if (section.isPresent()) {
            return section.get();
        } else {
            throw new SectionNotFoundException(id);
        }
    }

    // =====================
    //         SAVE
    // =====================

    @Override
    public Section saveSection(Section section) {
        return sectionRepository.save(section);
    }

    // =====================
    //         DELETE
    // =====================

    @Override
    public void deleteSection(Integer id) {
        sectionRepository.deleteById(id);
    }


}
